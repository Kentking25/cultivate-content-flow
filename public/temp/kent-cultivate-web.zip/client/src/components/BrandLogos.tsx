/*
 * BrandLogos — ZoomParallax mosaic of brand logos for the "Trusted By" section
 * Design: FolioBlox Bold — dark #0A0A0A background, bare PNG logos (no boxes),
 *         larger uniform size, white-filtered, zoom-in on scroll
 */

import { useRef } from 'react';
import { useScroll, useTransform, motion, type MotionValue } from 'framer-motion';

interface Brand {
  name: string;
  logoUrl: string;
  invert?: boolean;
}

const CDN = 'https://d2xsxph8kpxj0f.cloudfront.net/93516502/NBG5nNH8rPYUKArCivqvbL';

const BRANDS: Brand[] = [
  // Transparent PNGs processed from Kent's uploaded logos
  { name: 'Microsoft', logoUrl: `${CDN}/windows-white-text_e73fba6b.png`, invert: false },
  { name: 'Dr. Squatch', logoUrl: `${CDN}/dr-squatch_1832cbd9.png`, invert: true },
  { name: 'Printify', logoUrl: `${CDN}/printify_a8b8c490.png`, invert: true },
  { name: 'Zeffy', logoUrl: `${CDN}/zeffy_86b576ef.png`, invert: true },
  { name: 'Kajabi', logoUrl: `${CDN}/kajabi_05858aa0.png`, invert: true },
  { name: 'Skillz', logoUrl: `${CDN}/skillz_829e19c8.png`, invert: true },
  { name: 'inBeat', logoUrl: `${CDN}/inbeat_a8b736d9.png`, invert: true },
  { name: 'Reebok', logoUrl: `${CDN}/reebok_3f7b625c.png`, invert: false },
  { name: 'Sprite', logoUrl: `${CDN}/sprite_95df5606.png`, invert: false },
  { name: 'CRWN Mag', logoUrl: `${CDN}/crwn_b47f9179.png`, invert: true },
  { name: 'Magfast', logoUrl: `${CDN}/magfast_e97d04de.png`, invert: false },
  { name: 'MNTN', logoUrl: `${CDN}/mntn_0fe25d65.png`, invert: true },
  { name: 'Everyday Dose', logoUrl: `${CDN}/everydaydose-new_f6aa3804.png`, invert: false },
  { name: 'Honda', logoUrl: `${CDN}/honda_ee3b55fd.png`, invert: true },
  { name: 'BET', logoUrl: `${CDN}/bet_49a3c920.png`, invert: true },
  { name: 'Fujifilm', logoUrl: `${CDN}/fujifilm_d8de7fa1.png`, invert: true },
];

// Mosaic positions — each brand floats at a different offset from center
const POSITIONS = [
  { top: '0vh',   left: '0vw',   w: '120px' },
  { top: '-22vh', left: '-18vw', w: '110px' },
  { top: '-22vh', left: '18vw',  w: '110px' },
  { top: '22vh',  left: '-18vw', w: '110px' },
  { top: '22vh',  left: '18vw',  w: '110px' },
  { top: '-30vh', left: '0vw',   w: '100px' },
  { top: '30vh',  left: '0vw',   w: '100px' },
  { top: '0vh',   left: '-32vw', w: '100px' },
  { top: '0vh',   left: '32vw',  w: '100px' },
  { top: '-14vh', left: '-32vw', w: '90px' },
  { top: '14vh',  left: '-32vw', w: '90px' },
  { top: '-14vh', left: '32vw',  w: '90px' },
  { top: '14vh',  left: '32vw',  w: '90px' },
  { top: '-35vh', left: '-10vw', w: '85px' },
  { top: '-35vh', left: '10vw',  w: '85px' },
  { top: '35vh',  left: '-10vw', w: '85px' },
];

// Each brand zooms in at a different rate — [from, to]
const SCALE_FACTORS = [
  [1, 9] as const, [1, 6] as const, [1, 6] as const, [1, 6] as const, [1, 6] as const,
  [1, 5] as const, [1, 5] as const, [1, 5] as const, [1, 5] as const,
  [1, 4] as const, [1, 4] as const, [1, 4] as const, [1, 4] as const,
  [1, 4] as const, [1, 4] as const, [1, 4] as const,
];

// Individual brand item — receives pre-computed scale
function BrandItem({ brand, scale, pos }: {
  brand: Brand;
  scale: MotionValue<number>;
  pos: typeof POSITIONS[0];
}) {
  return (
    <motion.div
      style={{
        scale,
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <div
        style={{
          position: 'relative',
          top: pos.top,
          left: pos.left,
          width: pos.w,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <img
          src={brand.logoUrl}
          alt={brand.name}
          style={{
            width: '100%',
            height: 'auto',
            maxHeight: '60px',
            objectFit: 'contain',
            filter: brand.invert
              ? 'brightness(0) invert(1) opacity(0.85)'
              : 'opacity(0.85)',
          }}
        />
      </div>
    </motion.div>
  );
}

export function BrandLogos() {
  const container = useRef(null);
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ['start start', 'end end'],
  });

  // Pre-compute all 16 scale transforms at the top level (hooks rules compliant)
  const s0  = useTransform(scrollYProgress, [0, 1], [1, 9]);
  const s1  = useTransform(scrollYProgress, [0, 1], [1, 6]);
  const s2  = useTransform(scrollYProgress, [0, 1], [1, 6]);
  const s3  = useTransform(scrollYProgress, [0, 1], [1, 6]);
  const s4  = useTransform(scrollYProgress, [0, 1], [1, 6]);
  const s5  = useTransform(scrollYProgress, [0, 1], [1, 5]);
  const s6  = useTransform(scrollYProgress, [0, 1], [1, 5]);
  const s7  = useTransform(scrollYProgress, [0, 1], [1, 5]);
  const s8  = useTransform(scrollYProgress, [0, 1], [1, 5]);
  const s9  = useTransform(scrollYProgress, [0, 1], [1, 4]);
  const s10 = useTransform(scrollYProgress, [0, 1], [1, 4]);
  const s11 = useTransform(scrollYProgress, [0, 1], [1, 4]);
  const s12 = useTransform(scrollYProgress, [0, 1], [1, 4]);
  const s13 = useTransform(scrollYProgress, [0, 1], [1, 4]);
  const s14 = useTransform(scrollYProgress, [0, 1], [1, 4]);
  const s15 = useTransform(scrollYProgress, [0, 1], [1, 4]);

  const scales = [s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13, s14, s15];

  return (
    <section style={{ background: '#0A0A0A', position: 'relative' }}>
      {/* Section header */}
      <div style={{ textAlign: 'center', padding: '5rem 1.5rem 2rem', position: 'relative', zIndex: 2 }}>
        <p style={{
          fontFamily: 'var(--font-display)', fontSize: '0.6rem', fontWeight: 700,
          letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--orange)',
          marginBottom: '1rem',
        }}>
          TRUSTED BY
        </p>
        <h2 style={{
          fontFamily: 'var(--font-display)', fontWeight: 700,
          fontSize: 'clamp(2rem, 5vw, 3.5rem)', color: '#fff',
          letterSpacing: '-0.03em', lineHeight: 1.05, marginBottom: '0.75rem',
        }}>
          Great content should be{' '}
          <span style={{ color: 'var(--orange)' }}>cultivated</span> — not forced.
        </h2>
        <p style={{
          fontFamily: 'var(--font-body)', fontSize: 'clamp(0.85rem, 1.5vw, 1rem)',
          color: 'rgba(255,255,255,0.45)', maxWidth: '420px', margin: '0 auto',
          lineHeight: 1.7,
        }}>
          These brands trusted the formula. The results speak for themselves.
        </p>
      </div>

      {/* Zoom parallax container */}
      <div ref={container} style={{ position: 'relative', height: '300vh', zIndex: 1 }}>
        <div style={{ position: 'sticky', top: 0, height: '100vh', overflow: 'hidden' }}>
          {BRANDS.map((brand, index) => (
            <BrandItem
              key={brand.name}
              brand={brand}
              scale={scales[index]}
              pos={POSITIONS[index % POSITIONS.length]}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
