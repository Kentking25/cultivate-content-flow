/*
 * Navigation — Version 2 "FolioBlox Bold"
 * - Pure black bg on scroll, transparent on hero
 * - Logo: wordmark left, pill CTA right
 * - Mobile: hamburger with full-screen overlay
 */

import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  const navLinks = [
    { label: "Services", href: "/#services" },
    { label: "Speaking", href: "/speaking" },
    { label: "Agency", href: "/agency" },
  ];

  return (
    <>
      <nav
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          zIndex: 100,
          transition: "background 0.3s ease, border-color 0.3s ease",
          backgroundColor: scrolled ? "rgba(10,10,10,0.97)" : "transparent",
          borderBottom: scrolled ? "1px solid rgba(255,255,255,0.07)" : "1px solid transparent",
          backdropFilter: scrolled ? "blur(12px)" : "none",
        }}
      >
        <div
          className="container"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            height: "70px",
          }}
        >
          {/* Logo */}
          <Link href="/">
            <div style={{ cursor: "pointer" }}>
              <div
                style={{
                  fontFamily: "var(--font-display)",
                  fontWeight: 700,
                  fontSize: "1rem",
                  color: "#fff",
                  letterSpacing: "-0.01em",
                  lineHeight: 1,
                }}
              >
                Kent King
              </div>
              <div
                style={{
                  fontFamily: "var(--font-display)",
                  fontSize: "0.58rem",
                  fontWeight: 500,
                  color: "var(--orange)",
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                  marginTop: "2px",
                }}
              >
                The Content Chemist
              </div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center" style={{ gap: "2rem" }}>
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                style={{
                  fontFamily: "var(--font-display)",
                  fontSize: "0.82rem",
                  fontWeight: 500,
                  color: "rgba(255,255,255,0.6)",
                  textDecoration: "none",
                  letterSpacing: "0.01em",
                  transition: "color 0.2s ease",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.color = "#fff")}
                onMouseLeave={(e) => (e.currentTarget.style.color = "rgba(255,255,255,0.6)")}
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* CTA + Hamburger */}
          <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
            <a
              href="https://superprofile.bio/bookings/kentcultivate?sessionId=689616ac04f931001305c667"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-pill hidden md:inline-flex"
              style={{ fontSize: "0.78rem", padding: "0.6rem 1.2rem" }}
            >
              Book 1:1
              <span className="arrow-circle" style={{ background: "rgba(255,255,255,0.25)" }}>→</span>
            </a>

            {/* Hamburger */}
            <button
              className="md:hidden"
              onClick={() => setMobileOpen(!mobileOpen)}
              style={{
                background: "none",
                border: "none",
                color: "#fff",
                cursor: "pointer",
                padding: "0.25rem",
                display: "flex",
                flexDirection: "column",
                gap: "5px",
                width: "28px",
              }}
              aria-label="Toggle menu"
            >
              <span style={{ display: "block", height: "2px", background: "#fff", borderRadius: "2px", transition: "transform 0.3s ease, opacity 0.3s ease", transform: mobileOpen ? "translateY(7px) rotate(45deg)" : "none" }} />
              <span style={{ display: "block", height: "2px", background: "#fff", borderRadius: "2px", transition: "opacity 0.3s ease", opacity: mobileOpen ? 0 : 1 }} />
              <span style={{ display: "block", height: "2px", background: "#fff", borderRadius: "2px", transition: "transform 0.3s ease, opacity 0.3s ease", transform: mobileOpen ? "translateY(-7px) rotate(-45deg)" : "none" }} />
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Overlay */}
      <div
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 99,
          backgroundColor: "#0A0A0A",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          padding: "2rem",
          transition: "opacity 0.3s ease, transform 0.3s ease",
          opacity: mobileOpen ? 1 : 0,
          transform: mobileOpen ? "translateY(0)" : "translateY(-100%)",
          pointerEvents: mobileOpen ? "all" : "none",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: "2rem" }}>
          {navLinks.map((link, i) => (
            <a
              key={link.label}
              href={link.href}
              onClick={() => setMobileOpen(false)}
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "2.5rem",
                fontWeight: 700,
                color: "#fff",
                textDecoration: "none",
                letterSpacing: "-0.02em",
                transition: `opacity 0.3s ease ${i * 0.05}s, transform 0.3s ease ${i * 0.05}s`,
                opacity: mobileOpen ? 1 : 0,
                transform: mobileOpen ? "translateX(0)" : "translateX(-20px)",
              }}
            >
              {link.label}
            </a>
          ))}
        </div>
        <div style={{ marginTop: "3rem" }}>
          <a
            href="https://superprofile.bio/bookings/kentcultivate?sessionId=689616ac04f931001305c667"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-pill"
            onClick={() => setMobileOpen(false)}
          >
            Book 1:1 Call
            <span className="arrow-circle" style={{ background: "rgba(255,255,255,0.25)" }}>→</span>
          </a>
        </div>
      </div>
    </>
  );
}
