/*
 * SocialProofScroll — SmoothScrollHero-style parallax for the Client Roster section
 * Design: FolioBlox Bold — sticky center image expands via clip-path, surrounding
 * client profile cards float at different parallax rates as you scroll
 * Based on pasted_content_8 (modern-hero.tsx) pattern
 */

import React, { useRef } from 'react';
import {
  motion,
  useMotionTemplate,
  useScroll,
  useTransform,
} from 'framer-motion';

const SECTION_HEIGHT = 1500;

interface ClientProfile {
  username: string;
  displayName: string;
  niche: string;
  followers: string;
  avatarColor: string;
  avatarInitials: string;
  verified?: boolean;
  bio: string;
}

const CLIENTS: ClientProfile[] = [
  {
    username: 'trapkaraoke',
    displayName: 'Trap Karaoke®',
    niche: 'Live Events & Entertainment',
    followers: '649K',
    avatarColor: 'linear-gradient(135deg, #7a0000, #3d0000)',
    avatarInitials: 'TK',
    verified: true,
    bio: 'Concert Tour. Spiritual enlightenment starts here ✨',
  },
  {
    username: 'teriijeoma',
    displayName: 'Teri Ijeoma ™️',
    niche: 'Stock Trading Educator',
    followers: '168K',
    avatarColor: 'linear-gradient(135deg, #16213e, #1a1a2e)',
    avatarInitials: 'TI',
    verified: true,
    bio: 'Helping ambitious people generate income from stocks.',
  },
  {
    username: 'adeyemiadeyosoye',
    displayName: 'Adeyemi Adeyosoye',
    niche: "Men's Mindset & Business",
    followers: '234K',
    avatarColor: 'linear-gradient(135deg, #1c1c1c, #333)',
    avatarInitials: 'AA',
    verified: true,
    bio: 'The Radical Path for The Ambitious 1% Man.',
  },
  {
    username: 'coachkav',
    displayName: 'Justin Kavanaugh',
    niche: 'High-Performance Coach',
    followers: '113K',
    avatarColor: 'linear-gradient(135deg, #0d2b0d, #1a3a1a)',
    avatarInitials: 'JK',
    bio: 'Olympic coach of 23 years, 47 world champions.',
  },
  {
    username: 'benniebates',
    displayName: 'BEZELS',
    niche: 'Artist',
    followers: '105K',
    avatarColor: 'linear-gradient(135deg, #0f0f0f, #2a2a2a)',
    avatarInitials: 'BB',
    bio: 'Artist. hope it was all worth it.',
  },
  {
    username: 'pajamabillionaire',
    displayName: 'Pajama Billionaire',
    niche: 'Entrepreneur & Lifestyle',
    followers: '76.7K',
    avatarColor: 'linear-gradient(135deg, #2a1a00, #4a3000)',
    avatarInitials: 'PB',
    bio: 'Building wealth in my pajamas.',
  },
  {
    username: 'lashesonfleek_',
    displayName: 'NIA MCCOY',
    niche: 'Beauty Educator',
    followers: '75K',
    avatarColor: 'linear-gradient(135deg, #2d1b4e, #4a1942)',
    avatarInitials: 'NM',
    bio: 'LASH QUEEN & EDUCATOR 🤍 Los Angeles / Glendale Ca',
  },
  {
    username: 'markwboswell',
    displayName: 'Mark W Boswell',
    niche: 'Weight Loss Coach',
    followers: '14.2K',
    avatarColor: 'linear-gradient(135deg, #0d1b2a, #1a2a3a)',
    avatarInitials: 'MB',
    bio: 'Online Weight loss Coach. fruitarian 🦍',
  },
];

function ClientCard({ client }: { client: ClientProfile }) {
  return (
    <div style={{
      background: 'rgba(10,10,10,0.92)',
      border: '1px solid rgba(255,255,255,0.1)',
      borderRadius: '16px',
      padding: '1.1rem',
      display: 'flex',
      flexDirection: 'column',
      gap: '0.6rem',
      backdropFilter: 'blur(12px)',
      width: '100%',
      height: '100%',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    }}>
      {/* Avatar + stats */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
        <div style={{
          width: '44px', height: '44px', borderRadius: '50%', flexShrink: 0,
          background: 'linear-gradient(135deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)',
          padding: '2px',
        }}>
          <div style={{
            width: '100%', height: '100%', borderRadius: '50%',
            background: client.avatarColor,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '0.85rem', fontWeight: 800, color: '#fff',
          }}>
            {client.avatarInitials}
          </div>
        </div>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
            <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#fff' }}>@{client.username}</span>
            {client.verified && (
              <svg width="11" height="11" viewBox="0 0 24 24" fill="#3b82f6">
                <path d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
              </svg>
            )}
          </div>
          <div style={{ fontSize: '0.62rem', color: 'rgba(255,255,255,0.4)', marginTop: '1px' }}>{client.niche}</div>
        </div>
      </div>

      {/* Followers highlight */}
      <div style={{
        background: 'rgba(255,85,0,0.12)',
        border: '1px solid rgba(255,85,0,0.2)',
        borderRadius: '8px',
        padding: '0.4rem 0.6rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <span style={{ fontSize: '0.6rem', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Followers</span>
        <span style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--orange)', fontFamily: 'var(--font-display)' }}>{client.followers}</span>
      </div>

      {/* Bio */}
      <p style={{
        fontSize: '0.65rem', color: 'rgba(255,255,255,0.55)', lineHeight: 1.5,
        display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
      }}>
        {client.bio}
      </p>
    </div>
  );
}

// Parallax image (card) component — same pattern as pasted_content_8 ParallaxImg
function ParallaxCard({
  client,
  start,
  end,
  className,
  style,
}: {
  client: ClientProfile;
  start: number;
  end: number;
  className?: string;
  style?: React.CSSProperties;
}) {
  const ref = useRef(null);

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: [`${start}px end`, `end ${end * -1}px`],
  });

  const opacity = useTransform(scrollYProgress, [0.75, 1], [1, 0]);
  const scale = useTransform(scrollYProgress, [0.75, 1], [1, 0.85]);
  const y = useTransform(scrollYProgress, [0, 1], [start, end]);
  const transform = useMotionTemplate`translateY(${y}px) scale(${scale})`;

  return (
    <motion.div
      ref={ref}
      className={className}
      style={{ transform, opacity, ...style }}
    >
      <ClientCard client={client} />
    </motion.div>
  );
}

// Center sticky card — expands via clip-path as you scroll (pasted_content_8 CenterImage pattern)
function CenterCard({ client }: { client: ClientProfile }) {
  const { scrollY } = useScroll();

  const clip1 = useTransform(scrollY, [0, SECTION_HEIGHT], [25, 0]);
  const clip2 = useTransform(scrollY, [0, SECTION_HEIGHT], [75, 100]);
  const clipPath = useMotionTemplate`polygon(${clip1}% ${clip1}%, ${clip2}% ${clip1}%, ${clip2}% ${clip2}%, ${clip1}% ${clip2}%)`;

  const backgroundSize = useTransform(
    scrollY,
    [0, SECTION_HEIGHT + 500],
    ['170%', '100%']
  );
  const opacity = useTransform(
    scrollY,
    [SECTION_HEIGHT, SECTION_HEIGHT + 500],
    [1, 0]
  );

  return (
    <motion.div
      className="sticky top-0 h-screen w-full"
      style={{
        clipPath,
        opacity,
        background: 'linear-gradient(135deg, #1a0a00, #0A0A0A)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {/* Centered featured client card */}
      <div style={{ width: '320px', maxWidth: '90vw' }}>
        <ClientCard client={client} />
      </div>
      {/* Overlay text */}
      <div style={{
        position: 'absolute',
        bottom: '10%',
        left: '50%',
        transform: 'translateX(-50%)',
        textAlign: 'center',
        pointerEvents: 'none',
      }}>
        <p style={{
          fontFamily: 'var(--font-display)', fontSize: '0.6rem', fontWeight: 700,
          letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--orange)',
        }}>
          CLIENT ROSTER
        </p>
      </div>
    </motion.div>
  );
}

export function SocialProofScroll() {
  return (
    <section style={{ background: '#0A0A0A' }}>
      {/* Section header */}
      <div style={{ textAlign: 'center', padding: '5rem 1.5rem 2rem' }}>
        <p style={{
          fontFamily: 'var(--font-display)', fontSize: '0.6rem', fontWeight: 700,
          letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--orange)',
          marginBottom: '1rem',
        }}>
          CLIENT ROSTER
        </p>
        <h2 style={{
          fontFamily: 'var(--font-display)', fontWeight: 700,
          fontSize: 'clamp(2rem, 5vw, 3.5rem)', color: '#fff',
          letterSpacing: '-0.03em', lineHeight: 1.05, marginBottom: '0.75rem',
        }}>
          Brands & Creators<br />
          <span style={{ color: 'var(--orange)' }}>who trusted the formula.</span>
        </h2>
        <p style={{
          fontFamily: 'var(--font-body)', fontSize: 'clamp(0.85rem, 1.5vw, 1rem)',
          color: 'rgba(255,255,255,0.4)', maxWidth: '480px', margin: '0 auto',
          lineHeight: 1.7,
        }}>
          From 14.2K to 649K followers — the Content Chemistry formula works at every level.
        </p>
      </div>

      {/* SmoothScrollHero section */}
      <div
        style={{ height: `calc(${SECTION_HEIGHT}px + 100vh)`, position: 'relative', width: '100%' }}
      >
        {/* Center sticky card — Trap Karaoke as the hero client */}
        <CenterCard client={CLIENTS[0]} />

        {/* Parallax floating cards */}
        <div style={{ margin: '0 auto', maxWidth: '1100px', padding: '200px 1.5rem 0', position: 'relative' }}>
          <ParallaxCard
            client={CLIENTS[1]}
            start={-200}
            end={200}
            style={{ width: '30%', minWidth: '200px', height: '160px' }}
          />
          <ParallaxCard
            client={CLIENTS[2]}
            start={200}
            end={-250}
            style={{ width: '55%', minWidth: '260px', height: '160px', margin: '2rem auto' }}
          />
          <ParallaxCard
            client={CLIENTS[3]}
            start={-200}
            end={200}
            style={{ width: '30%', minWidth: '200px', height: '160px', marginLeft: 'auto' }}
          />
          <ParallaxCard
            client={CLIENTS[4]}
            start={0}
            end={-500}
            style={{ width: '40%', minWidth: '220px', height: '160px', marginLeft: '5rem', marginTop: '2rem' }}
          />
          <ParallaxCard
            client={CLIENTS[5]}
            start={100}
            end={-300}
            style={{ width: '35%', minWidth: '200px', height: '160px', marginLeft: 'auto', marginTop: '-3rem' }}
          />
          <ParallaxCard
            client={CLIENTS[6]}
            start={-150}
            end={150}
            style={{ width: '30%', minWidth: '200px', height: '160px', marginTop: '2rem' }}
          />
          <ParallaxCard
            client={CLIENTS[7]}
            start={50}
            end={-200}
            style={{ width: '35%', minWidth: '200px', height: '160px', margin: '2rem auto 0' }}
          />
        </div>

        {/* Bottom fade */}
        <div style={{
          position: 'absolute', bottom: 0, left: 0, right: 0, height: '24rem',
          background: 'linear-gradient(to bottom, transparent, #0A0A0A)',
          pointerEvents: 'none',
        }} />
      </div>
    </section>
  );
}
