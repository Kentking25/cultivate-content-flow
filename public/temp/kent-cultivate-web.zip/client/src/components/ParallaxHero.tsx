/*
 * ParallaxHero — Full-screen hero with parallax scroll + floating callout tags
 * Design: FolioBlox Bold — pure black, orange accent, bold Space Grotesk
 * Uses framer-motion scroll transforms for parallax depth
 */

import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

interface ParallaxHeroProps {
  heroImg: string;
  img1: string;
  img2: string;
  img3: string;
}

export const ParallaxHero = ({ heroImg, img1, img2, img3 }: ParallaxHeroProps) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  const imgY = useTransform(scrollYProgress, [0, 1], ["0%", "25%"]);
  const overlayOpacity = useTransform(scrollYProgress, [0, 0.6], [0.45, 0.85]);
  const contentY = useTransform(scrollYProgress, [0, 1], ["0%", "20%"]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const tagsOpacity = useTransform(scrollYProgress, [0, 0.35], [1, 0]);

  const tags = [
    { label: "Creative Director", x: "4%", top: "24%" },
    { label: "Content Marketer", x: "68%", top: "20%" },
    { label: "Strategist", x: "72%", top: "68%" },
    { label: "Speaker", x: "4%", top: "66%" },
  ];

  return (
    <div
      ref={containerRef}
      style={{
        position: "relative",
        height: "100vh",
        overflow: "hidden",
        backgroundColor: "#0A0A0A",
      }}
    >
      {/* Parallax background image */}
      <motion.div
        style={{
          position: "absolute",
          inset: "-20% 0",
          y: imgY,
        }}
      >
        <img
          src={heroImg}
          alt="Kent King"
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            objectPosition: "center top",
            display: "block",
          }}
        />
      </motion.div>

      {/* Gradient overlay */}
      <motion.div
        style={{
          position: "absolute",
          inset: 0,
          opacity: overlayOpacity,
          background: "linear-gradient(to bottom, rgba(10,10,10,0.05) 0%, rgba(10,10,10,0.1) 25%, rgba(10,10,10,0.6) 58%, rgba(10,10,10,0.92) 78%, rgba(10,10,10,0.99) 100%)",
          pointerEvents: "none",
        }}
      />

      {/* Floating callout tags */}
      <motion.div
        style={{
          position: "absolute",
          inset: 0,
          pointerEvents: "none",
          opacity: tagsOpacity,
        }}
      >
        {tags.map((tag, i) => (
          <motion.div
            key={tag.label}
            initial={{ opacity: 0, scale: 0.85, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ delay: 0.5 + i * 0.1, duration: 0.5, ease: "easeOut" }}
            style={{
              position: "absolute",
              left: tag.x,
              top: tag.top,
            }}
          >
            <div
              style={{
                background: "rgba(10,10,10,0.72)",
                backdropFilter: "blur(14px)",
                WebkitBackdropFilter: "blur(14px)",
                border: "1px solid rgba(255,255,255,0.14)",
                borderRadius: "999px",
                padding: "0.45rem 1rem",
                fontFamily: "var(--font-display)",
                fontWeight: 700,
                fontSize: "clamp(0.6rem, 1.1vw, 0.78rem)",
                color: "#fff",
                letterSpacing: "0.02em",
                whiteSpace: "nowrap",
                display: "flex",
                alignItems: "center",
                gap: "0.45rem",
              }}
            >
              <span
                style={{
                  width: "6px",
                  height: "6px",
                  borderRadius: "50%",
                  backgroundColor: "var(--orange)",
                  flexShrink: 0,
                }}
              />
              {tag.label}
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* Hero content */}
      <motion.div
        style={{
          position: "absolute",
          bottom: "10%",
          left: 0,
          right: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          textAlign: "center",
          padding: "0 1.5rem",
          y: contentY,
          opacity: contentOpacity,
          zIndex: 10,
        }}
      >
        <motion.div
          initial={{ opacity: 1, y: 0 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <p
            style={{
              fontFamily: "var(--font-display)",
              fontWeight: 700,
              fontSize: "clamp(0.55rem, 0.9vw, 0.72rem)",
              letterSpacing: "0.22em",
              textTransform: "uppercase",
              color: "var(--orange)",
              marginBottom: "0.85rem",
            }}
          >
            The Content Chemist
          </p>
          <h1
            style={{
              fontFamily: "var(--font-display)",
              fontWeight: 700,
              fontSize: "clamp(4.5rem, 13vw, 10rem)",
              color: "#fff",
              letterSpacing: "-0.04em",
              lineHeight: 0.88,
              marginBottom: "1.5rem",
            }}
          >
            Kent King.
          </h1>
          <div
            style={{
              display: "flex",
              gap: "0.75rem",
              justifyContent: "center",
              flexWrap: "wrap",
            }}
          >
            <a
              href="/speaking"
              className="btn-pill"
              style={{ fontSize: "clamp(0.72rem, 1.4vw, 0.88rem)" }}
            >
              Book Me to Speak
              <span className="arrow-circle">→</span>
            </a>
            <a
              href="#story"
              className="btn-pill-outline"
              style={{ fontSize: "clamp(0.72rem, 1.4vw, 0.88rem)" }}
            >
              My Story
            </a>
          </div>
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 0.6 }}
        style={{
          position: "absolute",
          right: "1.5rem",
          bottom: "8%",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "0.5rem",
          pointerEvents: "none",
        }}
      >
        <span
          style={{
            fontFamily: "var(--font-display)",
            fontSize: "0.52rem",
            fontWeight: 700,
            letterSpacing: "0.22em",
            textTransform: "uppercase",
            color: "rgba(255,255,255,0.3)",
            writingMode: "vertical-rl",
          }}
        >
          SCROLL
        </span>
        <div
          style={{
            width: "1px",
            height: "40px",
            background: "linear-gradient(to bottom, rgba(255,255,255,0.3), transparent)",
          }}
        />
      </motion.div>

      {/* Text area scrim — ensures readability over warm background */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          height: "55%",
          background: "linear-gradient(to bottom, transparent 0%, rgba(5,5,5,0.55) 35%, rgba(5,5,5,0.88) 65%, rgba(5,5,5,0.99) 100%)",
          pointerEvents: "none",
          zIndex: 5,
        }}
      />

      {/* Bottom fade to black */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          height: "260px",
          background: "linear-gradient(to bottom, transparent, #0A0A0A)",
          pointerEvents: "none",
        }}
      />
    </div>
  );
};
