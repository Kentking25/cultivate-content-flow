/*
 * Timeline — Aceternity-inspired scroll-driven timeline
 * Version 2 "FolioBlox Bold" — orange accent line, bold year labels
 */

import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

export interface TimelineEntry {
  year: string;
  title: string;
  content: React.ReactNode;
}

export function Timeline({ data }: { data: TimelineEntry[] }) {
  const ref = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState(0);

  useEffect(() => {
    if (ref.current) {
      const rect = ref.current.getBoundingClientRect();
      setHeight(rect.height);
    }
  }, []);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start 10%", "end 60%"],
  });

  const heightTransform = useTransform(scrollYProgress, [0, 1], [0, height]);
  const opacityTransform = useTransform(scrollYProgress, [0, 0.05], [0, 1]);

  return (
    <div ref={containerRef} style={{ width: "100%", position: "relative" }}>
      <div ref={ref} style={{ position: "relative", maxWidth: "1200px", margin: "0 auto", paddingBottom: "4rem" }}>
        {data.map((item, index) => (
          <div
            key={index}
            style={{
              display: "flex",
              justifyContent: "flex-start",
              paddingTop: index === 0 ? "2rem" : "5rem",
              gap: "1.5rem",
            }}
          >
            {/* Left: year + dot */}
            <div
              style={{
                position: "sticky",
                top: "120px",
                alignSelf: "flex-start",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                width: "80px",
                flexShrink: 0,
              }}
            >
              {/* Dot */}
              <div
                style={{
                  width: "16px",
                  height: "16px",
                  borderRadius: "50%",
                  backgroundColor: "#0A0A0A",
                  border: "2px solid var(--orange)",
                  zIndex: 2,
                  marginBottom: "0.75rem",
                  flexShrink: 0,
                }}
              />
              {/* Year label */}
              <span
                style={{
                  fontFamily: "var(--font-display)",
                  fontWeight: 700,
                  fontSize: "clamp(1rem, 2vw, 1.4rem)",
                  color: "rgba(255,255,255,0.2)",
                  letterSpacing: "-0.02em",
                  writingMode: "horizontal-tb",
                  textAlign: "center",
                  lineHeight: 1.1,
                }}
              >
                {item.year}
              </span>
            </div>

            {/* Right: content */}
            <div style={{ flex: 1, paddingBottom: "2rem" }}>
              <h3
                style={{
                  fontFamily: "var(--font-display)",
                  fontWeight: 700,
                  fontSize: "clamp(1.2rem, 2.5vw, 1.6rem)",
                  color: "#fff",
                  letterSpacing: "-0.02em",
                  marginBottom: "0.75rem",
                  lineHeight: 1.2,
                }}
              >
                {item.title}
              </h3>
              {item.content}
            </div>
          </div>
        ))}

        {/* Vertical line track */}
        <div
          style={{
            position: "absolute",
            left: "39px",
            top: 0,
            bottom: 0,
            width: "2px",
            background: "rgba(255,255,255,0.07)",
          }}
        >
          <motion.div
            style={{
              height: heightTransform,
              opacity: opacityTransform,
              width: "2px",
              background: "linear-gradient(to bottom, transparent, var(--orange) 15%, var(--orange) 85%, transparent)",
              borderRadius: "2px",
            }}
          />
        </div>
      </div>
    </div>
  );
}
