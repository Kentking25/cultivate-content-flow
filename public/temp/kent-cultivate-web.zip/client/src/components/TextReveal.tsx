/*
 * TextReveal — Word-by-word scroll reveal
 * Based on Aceternity TextRevealByWord pattern (pasted_content_3)
 * Used for the hero tagline section
 */

import { FC, useRef } from "react";
import { motion, MotionValue, useScroll, useTransform } from "framer-motion";
import { cn } from "@/lib/utils";

interface TextRevealByWordProps {
  text: string;
  className?: string;
}

const TextRevealByWord: FC<TextRevealByWordProps> = ({ text, className }) => {
  const targetRef = useRef<HTMLDivElement | null>(null);

  const { scrollYProgress } = useScroll({
    target: targetRef,
    offset: ["start 0.9", "end 0.3"],
  });

  const words = text.split(" ");

  return (
    <div ref={targetRef} className={cn("relative z-0 h-[180vh]", className)}>
      <div className="sticky top-0 flex h-screen items-center justify-center">
        <p
          className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1 px-6 md:px-16 lg:px-24"
          style={{
            fontFamily: "var(--font-display)",
            fontWeight: 700,
            fontSize: "clamp(1.8rem, 4vw, 3.5rem)",
            letterSpacing: "-0.03em",
            lineHeight: 1.15,
            maxWidth: "900px",
            textAlign: "center",
          }}
        >
          {words.map((word, i) => {
            const start = i / words.length;
            const end = start + 1 / words.length;
            return (
              <Word key={i} progress={scrollYProgress} range={[start, end]}>
                {word}
              </Word>
            );
          })}
        </p>
      </div>
    </div>
  );
};

interface WordProps {
  children: React.ReactNode;
  progress: MotionValue<number>;
  range: [number, number];
}

const Word: FC<WordProps> = ({ children, progress, range }) => {
  const opacity = useTransform(progress, range, [0, 1]);
  const isOrange = typeof children === "string" && (
    children.toLowerCase().includes("strategy") ||
    children.toLowerCase().includes("execution") ||
    children.toLowerCase().includes("formula")
  );

  return (
    <span className="relative inline-block">
      <span style={{ opacity: 0.12, color: "#fff" }}>{children}</span>
      <motion.span
        style={{
          opacity,
          position: "absolute",
          left: 0,
          top: 0,
          color: isOrange ? "var(--orange)" : "#fff",
        }}
      >
        {children}
      </motion.span>
    </span>
  );
};

export { TextRevealByWord };
