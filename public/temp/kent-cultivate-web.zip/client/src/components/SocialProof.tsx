/**
 * SocialProof — Instagram mobile screenshot-style cards
 * Design: Exact match to the mobile IG profile screenshot provided by Kent:
 *   - Pure black background (#0A0A0A)
 *   - Large bold username at top with verified badge
 *   - IG gradient ring (red→orange→yellow→purple) around profile photo
 *   - Big stats row: posts / followers / following
 *   - Category label + full bio text
 *   - "Following ✓" button
 *   - Horizontal drag-to-scroll layout
 * Real data scraped from each profile page.
 */

import { motion } from "framer-motion";
import { useRef } from "react";

interface IGProfile {
  handle: string;
  name: string;
  verified: boolean;
  posts: string;
  followers: string;
  following: string;
  bio: string;
  category: string;
  avatar: string;
}

const PROFILES: IGProfile[] = [
  {
    handle: "teriijeoma",
    name: "Teri Ijeoma ™️",
    verified: true,
    posts: "237",
    followers: "168K",
    following: "7,232",
    bio: "Helping ambitious people generate income from stocks so they can do things they love. Creator: @tradeandtravel",
    category: "Stock Trading Educator",
    avatar: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=200&h=200&fit=crop&crop=face",
  },
  {
    handle: "adeyemiadeyosoye",
    name: "Adeyemi Adeyosoye",
    verified: true,
    posts: "856",
    followers: "234K",
    following: "131",
    bio: "The Radical Path for The Ambitious 1% Man. Become Undeniable — In bed and in business. The key? Dark Masculine Mastery. Comment ERUPT to begin ↓",
    category: "Men's Mindset & Business",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face",
  },
  {
    handle: "lashesonfleek_",
    name: "NIA MCCOY",
    verified: false,
    posts: "459",
    followers: "75K",
    following: "709",
    bio: "LASH QUEEN & EDUCATOR 🤍 SERVICES | SUPPLIES | CLASSES 📍 Los Angeles / Glendale Ca 🔗 To Schedule The Experience",
    category: "Beauty Educator",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=face",
  },
  {
    handle: "benniebates",
    name: "BEZELS",
    verified: true,
    posts: "23",
    followers: "105K",
    following: "3,556",
    bio: "Artist. hope it was all worth it.",
    category: "Artist",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face",
  },
  {
    handle: "coachkav",
    name: "Justin Kavanaugh",
    verified: false,
    posts: "1,733",
    followers: "113K",
    following: "7,503",
    bio: "Olympic coach of 23 years, 47 world champions and not slowing down. 🥇 HOW TO WIN.",
    category: "High-Performance Coach",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face",
  },
  {
    handle: "trapkaraoke",
    name: "Trap Karaoke®",
    verified: true,
    posts: "3,938",
    followers: "649K",
    following: "6,351",
    bio: "Concert Tour. Spiritual enlightenment starts here ✨ #TK11years. Meet the cousins @cuzfest @chopkaraoke",
    category: "Live Events & Entertainment",
    avatar: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=200&h=200&fit=crop&crop=center",
  },
  {
    handle: "markwboswell",
    name: "Mark W Boswell",
    verified: false,
    posts: "537",
    followers: "14.2K",
    following: "298",
    bio: "Online Weight loss Coach ▫️ www.MarkWBoswell.com ▫️ YouTube MarkWBoswell ▫️ fruitarian 🦍",
    category: "Weight Loss Coach",
    avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop&crop=face",
  },
  {
    handle: "pajamabillionaire",
    name: "CHAVEZ ALLEN",
    verified: false,
    posts: "1,415",
    followers: "76.7K",
    following: "5,966",
    bio: "Entrepreneur. Wealth is the language. I'm fluent. Accredited. Global. Untouchable. Billionaire.",
    category: "Forex Trader & Entrepreneur",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop&crop=face",
  },
];

function IGCard({ profile, index }: { profile: IGProfile; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.6, delay: index * 0.07, ease: [0.22, 1, 0.36, 1] }}
      style={{
        background: "#0A0A0A",
        border: "1px solid rgba(255,255,255,0.09)",
        borderRadius: "20px",
        padding: "1.25rem",
        minWidth: "300px",
        maxWidth: "340px",
        flexShrink: 0,
        boxShadow: "0 20px 60px rgba(0,0,0,0.5)",
      }}
    >
      {/* Top bar: back arrow + handle + verified + icons */}
      <div style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: "1.25rem",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
          <span style={{ color: "rgba(255,255,255,0.4)", fontSize: "1.2rem", lineHeight: 1 }}>‹</span>
          <span style={{
            fontFamily: "var(--font-display)",
            fontWeight: 700,
            fontSize: "1rem",
            color: "#fff",
            letterSpacing: "-0.02em",
          }}>
            {profile.handle}
          </span>
          {profile.verified && (
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="12" fill="#3897f0" />
              <path d="M7 12.5l3.5 3.5 6.5-7" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          )}
        </div>
        <div style={{ display: "flex", gap: "0.85rem", alignItems: "center" }}>
          {/* Bell */}
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.55)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
            <path d="M13.73 21a2 2 0 0 1-3.46 0" />
          </svg>
          {/* Dots */}
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.55)" strokeWidth="2" strokeLinecap="round">
            <circle cx="5" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" />
          </svg>
        </div>
      </div>

      {/* Avatar + stats */}
      <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "0.85rem" }}>
        {/* IG gradient ring */}
        <div style={{
          width: "76px",
          height: "76px",
          borderRadius: "50%",
          background: "linear-gradient(135deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%)",
          padding: "2.5px",
          flexShrink: 0,
        }}>
          <div style={{
            width: "100%",
            height: "100%",
            borderRadius: "50%",
            border: "2.5px solid #0A0A0A",
            overflow: "hidden",
            background: "#1a1a1a",
          }}>
            <img
              src={profile.avatar}
              alt={profile.name}
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
              onError={(e) => {
                (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(profile.name)}&background=1a1a1a&color=FF5500&size=80&bold=true`;
              }}
            />
          </div>
        </div>

        {/* Stats */}
        <div style={{ flex: 1, display: "flex", justifyContent: "space-around" }}>
          {[
            { val: profile.posts, label: "posts" },
            { val: profile.followers, label: "followers" },
            { val: profile.following, label: "following" },
          ].map((stat) => (
            <div key={stat.label} style={{ textAlign: "center" }}>
              <div style={{
                fontFamily: "var(--font-display)",
                fontWeight: 700,
                fontSize: "1.05rem",
                color: "#fff",
                letterSpacing: "-0.03em",
                lineHeight: 1.1,
              }}>
                {stat.val}
              </div>
              <div style={{
                fontFamily: "var(--font-body)",
                fontSize: "0.65rem",
                color: "rgba(255,255,255,0.45)",
                marginTop: "0.1rem",
              }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Name + category */}
      <div style={{ marginBottom: "0.5rem" }}>
        <div style={{
          fontFamily: "var(--font-display)",
          fontWeight: 700,
          fontSize: "0.85rem",
          color: "#fff",
          letterSpacing: "-0.01em",
        }}>
          {profile.name}
        </div>
        <div style={{
          fontFamily: "var(--font-body)",
          fontSize: "0.65rem",
          color: "rgba(255,255,255,0.35)",
          marginTop: "0.1rem",
        }}>
          {profile.category}
        </div>
      </div>

      {/* Bio */}
      <p style={{
        fontFamily: "var(--font-body)",
        fontSize: "0.75rem",
        color: "rgba(255,255,255,0.7)",
        lineHeight: 1.55,
        marginBottom: "1rem",
        minHeight: "3.5rem",
      }}>
        {profile.bio}
      </p>

      {/* Following button */}
      <button style={{
        width: "100%",
        padding: "0.5rem 1rem",
        background: "rgba(255,255,255,0.07)",
        border: "1px solid rgba(255,255,255,0.1)",
        borderRadius: "8px",
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: "0.78rem",
        color: "#fff",
        cursor: "default",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: "0.4rem",
        letterSpacing: "0.01em",
      }}>
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#FF5500" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="20 6 9 17 4 12" />
        </svg>
        Following
      </button>
    </motion.div>
  );
}

export function SocialProof() {
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    el.style.cursor = "grabbing";
    const startX = e.pageX - el.offsetLeft;
    const scrollLeft = el.scrollLeft;

    const onMove = (ev: MouseEvent) => {
      const x = ev.pageX - el.offsetLeft;
      el.scrollLeft = scrollLeft - (x - startX);
    };
    const onUp = () => {
      el.style.cursor = "grab";
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  return (
    <section style={{ padding: "7rem 0 6rem", background: "#080808", overflow: "hidden" }}>
      {/* Header */}
      <div className="container" style={{ marginBottom: "3.5rem" }}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        >
          <span style={{
            fontFamily: "var(--font-display)",
            fontSize: "0.6rem",
            fontWeight: 700,
            letterSpacing: "0.18em",
            textTransform: "uppercase",
            color: "var(--orange)",
            display: "block",
            marginBottom: "0.75rem",
          }}>
            Client Roster
          </span>
          <h2 style={{
            fontFamily: "var(--font-display)",
            fontWeight: 700,
            fontSize: "clamp(2rem, 5vw, 3.5rem)",
            color: "#fff",
            letterSpacing: "-0.04em",
            lineHeight: 0.95,
            marginBottom: "0.75rem",
          }}>
            Brands & Creators<br />
            <span style={{ color: "var(--orange)" }}>who trusted the formula.</span>
          </h2>
          <p style={{
            fontFamily: "var(--font-body)",
            fontSize: "0.875rem",
            color: "rgba(255,255,255,0.4)",
            maxWidth: "420px",
            lineHeight: 1.7,
          }}>
            From 14.2K to 649K followers — the Content Chemistry formula works at every level.
          </p>
        </motion.div>
      </div>

      {/* Horizontal scroll container */}
      <div
        ref={scrollRef}
        onMouseDown={handleMouseDown}
        style={{
          display: "flex",
          gap: "1.25rem",
          paddingLeft: "max(1rem, calc((100vw - 1280px) / 2 + 2rem))",
          paddingRight: "3rem",
          overflowX: "auto",
          scrollbarWidth: "none",
          msOverflowStyle: "none",
          paddingBottom: "0.5rem",
          cursor: "grab",
          WebkitOverflowScrolling: "touch",
        }}
      >
        {PROFILES.map((profile, i) => (
          <IGCard key={profile.handle} profile={profile} index={i} />
        ))}
      </div>

      {/* Drag hint */}
      <div className="container" style={{ marginTop: "1.75rem" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.6rem" }}>
          <div style={{ width: "2rem", height: "1px", background: "var(--orange)" }} />
          <span style={{
            fontFamily: "var(--font-display)",
            fontSize: "0.6rem",
            fontWeight: 700,
            letterSpacing: "0.12em",
            textTransform: "uppercase",
            color: "rgba(255,255,255,0.2)",
          }}>
            Drag to explore
          </span>
        </div>
      </div>
    </section>
  );
}

export default SocialProof;
