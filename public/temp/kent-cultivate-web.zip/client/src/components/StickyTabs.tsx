/*
 * StickyTabs — Sticky scroll stacking animation for Work section
 * Based on pasted_content_6 sticky-section-tabs pattern
 * Each case study stacks on scroll with a sticky header revealing the brand name
 * Design: FolioBlox Bold — pure black, orange accent, Space Grotesk
 */

import React, { Children, isValidElement } from "react";

interface StickyTabItemProps {
  title: string;
  id: string | number;
  children: React.ReactNode;
}

const StickyTabItem: React.FC<StickyTabItemProps> = () => null;

interface StickyTabsProps {
  children: React.ReactNode;
  mainNavHeight?: string;
}

const StickyTabs: React.FC<StickyTabsProps> & { Item: React.FC<StickyTabItemProps> } = ({
  children,
  mainNavHeight = "64px",
}) => {
  const stickyTopValue = `calc(${mainNavHeight} - 1px)`;
  const navHeightStyle = { height: mainNavHeight };
  const stickyHeaderStyle = { top: stickyTopValue };

  return (
    <div style={{ overflow: "clip", background: "#0A0A0A", color: "#fff" }}>
      {/* Nav spacer */}
      <div
        style={{
          position: "sticky",
          left: 0,
          top: 0,
          zIndex: 20,
          width: "100%",
          borderBottom: "1px solid rgba(255,255,255,0.06)",
          background: "#0A0A0A",
          ...navHeightStyle,
        }}
        aria-hidden="true"
      />

      {Children.map(children, (child) => {
        if (!isValidElement(child) || child.type !== StickyTabItem) return null;

        const itemElement = child as React.ReactElement<StickyTabItemProps>;
        const { title, id, children: itemContent } = itemElement.props;

        return (
          <section
            key={id}
            style={{ position: "relative", overflow: "clip", background: "#111111" }}
          >
            {/* Sticky brand header */}
            <div
              style={{
                position: "sticky",
                zIndex: 10,
                marginTop: "-1px",
                display: "flex",
                flexDirection: "column",
                boxShadow: "0 4px 24px rgba(0,0,0,0.4)",
                ...stickyHeaderStyle,
              }}
            >
              <div style={{
                borderBottom: "1px solid rgba(255,255,255,0.08)",
                borderTop: "1px solid rgba(255,255,255,0.08)",
                background: "#0A0A0A",
              }}>
                <div style={{
                  maxWidth: "1280px",
                  margin: "0 auto",
                  padding: "1.25rem 2rem",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}>
                  <h2 style={{
                    fontFamily: "var(--font-display)",
                    fontWeight: 700,
                    fontSize: "clamp(1.5rem, 3vw, 2.5rem)",
                    color: "#fff",
                    letterSpacing: "-0.03em",
                    lineHeight: 1,
                    margin: 0,
                  }}>
                    {title}
                  </h2>
                  <div style={{
                    width: "8px",
                    height: "8px",
                    borderRadius: "50%",
                    background: "var(--orange)",
                    flexShrink: 0,
                  }} />
                </div>
              </div>
            </div>

            {/* Case study content */}
            <div style={{
              maxWidth: "1280px",
              margin: "0 auto",
              padding: "4rem 2rem",
            }}>
              {itemContent}
            </div>
          </section>
        );
      })}
    </div>
  );
};

StickyTabs.Item = StickyTabItem;

export default StickyTabs;
