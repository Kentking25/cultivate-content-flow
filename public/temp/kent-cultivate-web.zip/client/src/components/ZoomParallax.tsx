/*
 * ZoomParallax — Sticky scroll zoom mosaic for Social Proof section
 * Design: FolioBlox Bold — each "image" is an IG profile card rendered as a canvas element
 * Based on pasted_content_7 pattern: framer-motion scroll transforms with different scale rates
 */

'use client';

import React, { useRef } from 'react';
import { useScroll, useTransform, motion } from 'framer-motion';

interface IGProfile {
  username: string;
  displayName: string;
  niche: string;
  posts: string;
  followers: string;
  following: string;
  bio: string;
  verified?: boolean;
  avatarColor: string;
  avatarInitials: string;
}

interface ZoomParallaxProps {
  profiles: IGProfile[];
  sectionLabel?: string;
  sectionTitle?: React.ReactNode;
  sectionSubtitle?: string;
}

function IGCard({ profile }: { profile: IGProfile }) {
  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        background: '#000',
        borderRadius: '16px',
        padding: '1.1rem',
        display: 'flex',
        flexDirection: 'column',
        gap: '0.75rem',
        border: '1px solid rgba(255,255,255,0.08)',
        overflow: 'hidden',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      }}
    >
      {/* Top bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="2">
            <polyline points="15 18 9 12 15 6" />
          </svg>
          <span style={{ fontSize: '0.78rem', fontWeight: 700, color: '#fff' }}>@{profile.username}</span>
          {profile.verified && (
            <svg width="13" height="13" viewBox="0 0 24 24" fill="#3b82f6">
              <path d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
            </svg>
          )}
        </div>
        <div style={{ display: 'flex', gap: '0.6rem' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="2">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.73 21a2 2 0 0 1-3.46 0" />
          </svg>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="2">
            <circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /><circle cx="5" cy="12" r="1" />
          </svg>
        </div>
      </div>

      {/* Profile row */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
        {/* Avatar with IG gradient ring */}
        <div style={{
          width: '52px', height: '52px', borderRadius: '50%', flexShrink: 0,
          background: 'linear-gradient(135deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)',
          padding: '2px',
        }}>
          <div style={{
            width: '100%', height: '100%', borderRadius: '50%',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '1rem', fontWeight: 800, color: '#fff',
            background: profile.avatarColor,
          }}>
            {profile.avatarInitials}
          </div>
        </div>

        {/* Stats */}
        <div style={{ display: 'flex', gap: '0.9rem', flex: 1 }}>
          {[
            { value: profile.posts, label: 'posts' },
            { value: profile.followers, label: 'followers' },
            { value: profile.following, label: 'following' },
          ].map((stat) => (
            <div key={stat.label} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '0.9rem', fontWeight: 700, color: '#fff', lineHeight: 1.1 }}>{stat.value}</div>
              <div style={{ fontSize: '0.6rem', color: 'rgba(255,255,255,0.5)', marginTop: '1px' }}>{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Name + niche */}
      <div>
        <div style={{ fontSize: '0.78rem', fontWeight: 700, color: '#fff', lineHeight: 1.2 }}>{profile.displayName}</div>
        <div style={{ fontSize: '0.65rem', color: 'rgba(255,255,255,0.45)', marginTop: '1px' }}>{profile.niche}</div>
      </div>

      {/* Bio */}
      <div style={{
        fontSize: '0.68rem', color: 'rgba(255,255,255,0.75)', lineHeight: 1.5,
        display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden',
      }}>
        {profile.bio}
      </div>

      {/* Following button */}
      <div style={{
        marginTop: 'auto',
        background: 'rgba(255,255,255,0.1)',
        border: '1px solid rgba(255,255,255,0.15)',
        borderRadius: '8px',
        padding: '0.35rem',
        textAlign: 'center',
        fontSize: '0.7rem',
        fontWeight: 700,
        color: '#fff',
      }}>
        Following ✓
      </div>
    </div>
  );
}

export function ZoomParallax({ profiles, sectionLabel, sectionTitle, sectionSubtitle }: ZoomParallaxProps) {
  const container = useRef(null);
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ['start start', 'end end'],
  });

  const scale4 = useTransform(scrollYProgress, [0, 1], [1, 4]);
  const scale5 = useTransform(scrollYProgress, [0, 1], [1, 5]);
  const scale6 = useTransform(scrollYProgress, [0, 1], [1, 6]);
  const scale8 = useTransform(scrollYProgress, [0, 1], [1, 8]);
  const scale9 = useTransform(scrollYProgress, [0, 1], [1, 9]);

  const scales = [scale4, scale5, scale6, scale5, scale6, scale8, scale9, scale4];

  // Layout positions for up to 8 cards — adapted from the 7-image ZoomParallax pattern
  const positions = [
    // Center card — largest, no offset
    { top: undefined, left: undefined, width: '25vw', height: '25vh' },
    // Top-left
    { top: '-30vh', left: '5vw', width: '22vw', height: '28vh' },
    // Top-right
    { top: '-10vh', left: '-25vw', width: '20vw', height: '30vh' },
    // Right
    { top: undefined, left: '27.5vw', width: '20vw', height: '25vh' },
    // Bottom-left
    { top: '27.5vh', left: '5vw', width: '20vw', height: '25vh' },
    // Bottom-center-left
    { top: '27.5vh', left: '-22.5vw', width: '22vw', height: '25vh' },
    // Far right
    { top: '22.5vh', left: '25vw', width: '15vw', height: '20vh' },
    // Top-center-right
    { top: '-25vh', left: '-10vw', width: '18vw', height: '22vh' },
  ];

  return (
    <section style={{ background: '#0A0A0A' }}>
      {/* Section header */}
      <div style={{ textAlign: 'center', padding: '5rem 1.5rem 2rem' }}>
        {sectionLabel && (
          <p style={{
            fontFamily: 'var(--font-display)', fontSize: '0.6rem', fontWeight: 700,
            letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--orange)',
            marginBottom: '1rem',
          }}>
            {sectionLabel}
          </p>
        )}
        {sectionTitle && (
          <h2 style={{
            fontFamily: 'var(--font-display)', fontWeight: 700,
            fontSize: 'clamp(2rem, 5vw, 3.5rem)', color: '#fff',
            letterSpacing: '-0.03em', lineHeight: 1.05, marginBottom: '1rem',
          }}>
            {sectionTitle}
          </h2>
        )}
        {sectionSubtitle && (
          <p style={{
            fontFamily: 'var(--font-body)', fontSize: 'clamp(0.85rem, 1.5vw, 1rem)',
            color: 'rgba(255,255,255,0.45)', maxWidth: '480px', margin: '0 auto',
            lineHeight: 1.7,
          }}>
            {sectionSubtitle}
          </p>
        )}
      </div>

      {/* Zoom parallax container */}
      <div ref={container} style={{ position: 'relative', height: '300vh' }}>
        <div style={{ position: 'sticky', top: 0, height: '100vh', overflow: 'hidden' }}>
          {profiles.slice(0, 8).map((profile, index) => {
            const scale = scales[index % scales.length];
            const pos = positions[index];

            return (
              <motion.div
                key={profile.username}
                style={{
                  scale,
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  width: '100%',
                  height: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <div
                  style={{
                    position: 'relative',
                    width: pos.width,
                    height: pos.height,
                    ...(pos.top !== undefined ? { top: pos.top } : {}),
                    ...(pos.left !== undefined ? { left: pos.left } : {}),
                  }}
                >
                  <IGCard profile={profile} />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
