/*
 * Footer — Version 2 "FolioBlox Bold"
 */

export default function Footer() {
  return (
    <footer style={{ backgroundColor: "#0A0A0A", borderTop: "1px solid rgba(255,255,255,0.07)", padding: "4rem 0 2rem" }}>
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-12">
          {/* Brand */}
          <div>
            <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.2rem", color: "#fff", letterSpacing: "-0.01em", marginBottom: "0.4rem" }}>
              Kent King
            </div>
            <div style={{ fontFamily: "var(--font-display)", fontSize: "0.58rem", fontWeight: 500, color: "var(--orange)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "1rem" }}>
              The Content Chemist
            </div>
            <p style={{ fontFamily: "var(--font-body)", fontSize: "0.85rem", color: "rgba(255,255,255,0.4)", lineHeight: 1.7, maxWidth: "260px" }}>
              Where creative meets conversions. Helping brands find their audience without dancing for the algorithm.
            </p>
          </div>

          {/* Navigate */}
          <div>
            <div style={{ fontFamily: "var(--font-display)", fontSize: "0.62rem", fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: "rgba(255,255,255,0.3)", marginBottom: "1rem" }}>
              Navigate
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "0.6rem" }}>
              {[
                { label: "About", href: "/#about" },
                { label: "Speaking", href: "/speaking" },
                { label: "Agency", href: "/agency" },
                { label: "Cohort Program", href: "https://contentclinic.live", external: true },
              ].map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  target={link.external ? "_blank" : undefined}
                  rel={link.external ? "noopener noreferrer" : undefined}
                  style={{ fontFamily: "var(--font-body)", fontSize: "0.85rem", color: "rgba(255,255,255,0.5)", textDecoration: "none", transition: "color 0.2s ease" }}
                  onMouseEnter={(e) => (e.currentTarget.style.color = "#fff")}
                  onMouseLeave={(e) => (e.currentTarget.style.color = "rgba(255,255,255,0.5)")}
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          {/* Work Together */}
          <div>
            <div style={{ fontFamily: "var(--font-display)", fontSize: "0.62rem", fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: "rgba(255,255,255,0.3)", marginBottom: "1rem" }}>
              Work Together
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
              <a href="https://superprofile.bio/bookings/kentcultivate?sessionId=689616ac04f931001305c667" target="_blank" rel="noopener noreferrer" className="btn-pill" style={{ alignSelf: "flex-start", fontSize: "0.78rem", padding: "0.6rem 1.2rem" }}>
                Book 1:1 Call
                <span className="arrow-circle" style={{ background: "rgba(255,255,255,0.25)" }}>→</span>
              </a>
              <a href="/agency" className="btn-pill-outline" style={{ alignSelf: "flex-start", fontSize: "0.78rem", padding: "0.6rem 1.2rem" }}>
                Apply to Agency
              </a>
              <a href="mailto:kent@kentcultivate.com" style={{ fontFamily: "var(--font-body)", fontSize: "0.82rem", color: "rgba(255,255,255,0.4)", textDecoration: "none", marginTop: "0.25rem" }}>
                kent@kentcultivate.com
              </a>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div style={{ borderTop: "1px solid rgba(255,255,255,0.07)", paddingTop: "1.5rem", display: "flex", flexWrap: "wrap", justifyContent: "space-between", alignItems: "center", gap: "1rem" }}>
          <span style={{ fontFamily: "var(--font-body)", fontSize: "0.78rem", color: "rgba(255,255,255,0.25)" }}>
            © 2026 Kent King. All rights reserved.
          </span>
          <div style={{ display: "flex", gap: "1.5rem" }}>
            {[
              { label: "Instagram", href: "https://instagram.com/kentcultivate" },
              { label: "TikTok", href: "https://tiktok.com/@kentcultivate" },
              { label: "YouTube", href: "https://youtube.com/@kentcultivate" },
            ].map((s) => (
              <a key={s.label} href={s.href} target="_blank" rel="noopener noreferrer"
                style={{ fontFamily: "var(--font-display)", fontSize: "0.7rem", fontWeight: 600, color: "rgba(255,255,255,0.3)", textDecoration: "none", letterSpacing: "0.05em", textTransform: "uppercase", transition: "color 0.2s ease" }}
                onMouseEnter={(e) => (e.currentTarget.style.color = "var(--orange)")}
                onMouseLeave={(e) => (e.currentTarget.style.color = "rgba(255,255,255,0.3)")}
              >
                {s.label}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
