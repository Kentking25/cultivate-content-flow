/*
 * Home — Version 3 "FolioBlox Bold + Scroll Magic"
 * Design: Pure black, Space Grotesk 700, orange #FF5500
 * New: ParallaxHero (clip-path reveal), TextReveal tagline,
 *      Role-label timeline (Actor/DJ/Marketer/Entrepreneur/Speaker),
 *      ContainerScroll work section, SocialProof IG marquee
 */

import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Timeline, type TimelineEntry } from "@/components/Timeline";
import { TextRevealByWord } from "@/components/TextReveal";
import { ContainerScroll } from "@/components/ContainerScroll";
import { BrandLogos } from "@/components/BrandLogos";
import { SocialProofScroll } from "@/components/SocialProofScroll";
import { ParallaxHero } from "@/components/ParallaxHero";
import StickyTabs from "@/components/StickyTabs";

// Generated images
const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/93516502/NBG5nNH8rPYUKArCivqvbL/kent-hero-real_b49edc4d.webp";
const SPEAKING_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/93516502/NBG5nNH8rPYUKArCivqvbL/me-talking_87af17df.webp";
const CREATIVE_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/93516502/NBG5nNH8rPYUKArCivqvbL/kent-creative-work_ad4a79d3.jpg";
const PORTRAIT_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/93516502/NBG5nNH8rPYUKArCivqvbL/kent-portrait-close_a71578e6.jpg";

// Real photos from Kent
const ACTOR_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/93516502/NBG5nNH8rPYUKArCivqvbL/hollywood_7a6c2f9f.png";
const DJ_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/93516502/NBG5nNH8rPYUKArCivqvbL/dj_957aaea3.jpg";
const MARKETER_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/93516502/NBG5nNH8rPYUKArCivqvbL/talking_fcaac1b1.png";
const ENTREPRENEUR_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/93516502/NBG5nNH8rPYUKArCivqvbL/portrait2_3db99df2.webp";
const SPEAKER_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/93516502/NBG5nNH8rPYUKArCivqvbL/me-talking_87af17df.webp";

// Animated counter hook
function useCountUp(target: number, duration = 2000) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const start = Date.now();
          const tick = () => {
            const elapsed = Date.now() - start;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setCount(Math.floor(eased * target));
            if (progress < 1) requestAnimationFrame(tick);
          };
          requestAnimationFrame(tick);
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target, duration]);

  return { count, ref };
}

function StatItem({ value, suffix, label }: { value: number; suffix: string; label: string }) {
  const { count, ref } = useCountUp(value);
  return (
    <div>
      <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(1.8rem, 3.5vw, 3rem)", color: "#fff", letterSpacing: "-0.04em", lineHeight: 1 }}>
        <span ref={ref}>{count}</span>{suffix}
      </div>
      <div style={{ fontFamily: "var(--font-display)", fontSize: "0.6rem", fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: "rgba(255,255,255,0.3)", marginTop: "0.35rem" }}>
        {label}
      </div>
    </div>
  );
}

// Timeline entry content helper
function TimelineContent({ img, body, stats }: { img: string; body: React.ReactNode; stats?: { val: string; label: string }[] }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "1.25rem" }}>
      <div
        style={{
          borderRadius: "12px",
          overflow: "hidden",
          aspectRatio: "16/9",
          maxWidth: "480px",
          position: "relative",
        }}
      >
        <img src={img} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center top", display: "block" }} />
        {/* Cinematic overlay — consistent dark gradient across all timeline images */}
        <div style={{
          position: "absolute",
          inset: 0,
          background: "linear-gradient(160deg, rgba(10,10,10,0.15) 0%, rgba(10,10,10,0.0) 40%, rgba(255,85,0,0.12) 70%, rgba(10,10,10,0.55) 100%)",
          pointerEvents: "none",
        }} />
      </div>
      <div style={{ fontFamily: "var(--font-body)", fontSize: "0.95rem", color: "rgba(255,255,255,0.65)", lineHeight: 1.8, maxWidth: "560px" }}>
        {body}
      </div>
      {stats && (
        <div style={{ display: "flex", gap: "2rem", flexWrap: "wrap" }}>
          {stats.map((s) => (
            <div key={s.label}>
              <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.5rem", color: "var(--orange)", letterSpacing: "-0.03em" }}>{s.val}</div>
              <div style={{ fontFamily: "var(--font-display)", fontSize: "0.6rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "rgba(255,255,255,0.3)", marginTop: "0.2rem" }}>{s.label}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const TIMELINE_DATA: TimelineEntry[] = [
  {
    year: "Actor",
    title: "From the Big Screen",
    content: (
      <TimelineContent
        img={ACTOR_IMG}
        body={
          <>
            It started on a movie set. As a kid actor, I appeared in <em>Losing Isaiah</em> alongside Halle Berry and shot commercials for Reebok and Sprite with Nas. That's where I first understood the power of media — how a single frame can make you feel something, buy something, believe something.
            <br /><br />
            I wasn't just watching — I was learning. The formula for attention is the same everywhere.
          </>
        }
      />
    ),
  },
  {
    year: "DJ",
    title: "Building a 6-Figure Brand",
    content: (
      <TimelineContent
        img={DJ_IMG}
        body={
          <>
            I became a DJ and event producer — and built a multi-6-figure brand from scratch. Toured nationally and internationally. Appeared on Hot97. Dropped out of college my senior year to pursue it full time.
            <br /><br />
            Not because I was reckless — because I understood the formula. Audience + energy + consistency = a brand that sustains itself.
          </>
        }
      />
    ),
  },
  {
    year: "Marketer",
    title: "The Pandemic Pivot — 10x Growth",
    content: (
      <TimelineContent
        img={MARKETER_IMG}
        body={
          <>
            When the world shut down, the events industry evaporated overnight. Most people panicked. I pivoted. I took everything I knew about live audiences and translated it to digital — and my following grew 10x.
            <br /><br />
            That's when I realized: the formula isn't platform-specific. It's human. Attention, connection, conversion — it works everywhere.
          </>
        }
        stats={[
          { val: "10x", label: "Follower Growth" },
          { val: "2020", label: "Pivot Year" },
          { val: "100%", label: "Digital Shift" },
        ]}
      />
    ),
  },
  {
    year: "Entrepreneur",
    title: "Element Creative Agency & The Content Chemist",
    content: (
      <TimelineContent
        img={ENTREPRENEUR_IMG}
        body={
          <>
            Today I run Element Creative Agency and engineer campaigns that convert audiences into communities and communities into customers. From the Microsoft CoPilot launch to directing retail expansion campaigns — I don't just create content. I architect experiences.
            <br /><br />
            I also created the Content Chemistry Method — a framework for building a personal brand that converts without chasing trends. Now I teach it through 1:1 calls, the Content Clinic cohort, and keynote stages.
          </>
        }
      />
    ),
  },
  {
    year: "Speaker",
    title: "On Stage — High Energy. No Fluff.",
    content: (
      <TimelineContent
        img={SPEAKER_IMG}
        body={
          <>
            50+ speaking engagements across conferences, summits, podcasts, and corporate events. I bring the same energy to a stage that I brought to the DJ booth — because the formula is the same. Give the audience something they can use, make them feel it, and leave them wanting more.
            <br /><br />
            Topics: Content Chemistry, AI-Powered Storytelling, From Audience to Community, The Creator Economy.
          </>
        }
        stats={[
          { val: "50+", label: "Engagements" },
          { val: "100K+", label: "Audience Reached" },
          { val: "4", label: "Signature Topics" },
        ]}
      />
    ),
  },
];

// Work case studies for ContainerScroll
const CASE_STUDIES = [
  {
    brand: "Microsoft",
    campaign: "CoPilot AI Launch",
    status: "COMPLETED",
    description: "Selected as the #1 top creative in Microsoft's CoPilot AI launch campaign. Produced content that drove 7M+ total impressions across platforms, outperforming every other creator in the campaign roster.",
    metrics: [{ val: "7M+", label: "Total Impressions" }, { val: "#1", label: "Top Creative in Campaign" }],
    color: "#00A4EF",
  },
  {
    brand: "MNTN",
    campaign: "Ongoing Brand Partnership",
    status: "ACTIVE",
    description: "An ongoing brand partnership built on consistent performance. Kent's content strategy for MNTN has generated 1.4M+ impressions and continues to deliver above-benchmark engagement with every campaign cycle.",
    metrics: [{ val: "1.4M+", label: "Impressions (Ongoing)" }, { val: "Top 5%", label: "Engagement Rate" }],
    color: "#FF5500",
  },
  {
    brand: "Everyday Dose",
    campaign: "Retail Expansion Campaign",
    status: "COMPLETED",
    description: "Developed the content strategy for Everyday Dose's retail expansion into Sprouts stores nationwide. The campaign bridged digital storytelling with in-store presence, driving awareness at a national scale.",
    metrics: [{ val: "Sprouts", label: "Retail Launch" }, { val: "Nationwide", label: "Distribution" }],
    color: "#4CAF50",
  },
  {
    brand: "Olive Gift Co",
    campaign: "ROAS Optimization",
    status: "COMPLETED",
    description: "Rebuilt the paid media content strategy for Olive Gift Co from the ground up. In just 30 days, the new creative approach increased return on ad spend by 1000% — without increasing the ad budget.",
    metrics: [{ val: "1000%", label: "ROAS Increase" }, { val: "1 Month", label: "Time to Results" }],
    color: "#C8A96E",
  },
];

// Contact form
function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", company: "", interest: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  if (submitted) {
    return (
      <div style={{ padding: "2.5rem", border: "1px solid rgba(255,85,0,0.3)", borderRadius: "12px", textAlign: "center" }}>
        <div style={{ color: "var(--orange)", fontSize: "2rem", marginBottom: "1rem" }}>✓</div>
        <h3 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.25rem", color: "#fff", marginBottom: "0.5rem" }}>Message Received</h3>
        <p style={{ fontFamily: "var(--font-body)", fontSize: "0.9rem", color: "rgba(255,255,255,0.45)" }}>Kent's team will be in touch within 2–3 business days.</p>
      </div>
    );
  }

  return (
    <form onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }} className="flex flex-col gap-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="form-field"><label className="form-label">Full Name *</label><input className="form-input" type="text" placeholder="Your name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
        <div className="form-field"><label className="form-label">Email *</label><input className="form-input" type="email" placeholder="your@email.com" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
      </div>
      <div className="form-field"><label className="form-label">Company / Brand</label><input className="form-input" type="text" placeholder="Your brand name" value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} /></div>
      <div className="form-field">
        <label className="form-label">I'm Interested In *</label>
        <select className="form-input" required value={form.interest} onChange={(e) => setForm({ ...form, interest: e.target.value })} style={{ appearance: "none", cursor: "pointer" }}>
          <option value="" disabled>Select an option</option>
          <option value="speaking">Speaking Engagement</option>
          <option value="agency">Agency Partnership</option>
          <option value="consulting">Brand Consulting</option>
          <option value="content">Content Creation</option>
          <option value="other">Something Else</option>
        </select>
      </div>
      <div className="form-field"><label className="form-label">Message *</label><textarea className="form-input" placeholder="Tell me about your vision..." required rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} style={{ resize: "vertical" }} /></div>
      <button type="submit" className="btn-pill" style={{ alignSelf: "flex-start" }}>
        Send Inquiry
        <span className="arrow-circle">→</span>
      </button>
    </form>
  );
}

export default function Home() {
  return (
    <div style={{ backgroundColor: "#0A0A0A", minHeight: "100vh" }}>
      <Navigation />

      {/* ── 1. PARALLAX HERO ── */}
      <ParallaxHero
        heroImg={HERO_IMG}
        img1={CREATIVE_IMG}
        img2={PORTRAIT_IMG}
        img3={SPEAKING_IMG}
      />

      {/* ── 2. TEXT REVEAL TAGLINE ── */}
      <TextRevealByWord
        text="Great content isn't posted — it's cultivated. Every brand has a story worth telling. My job is to find the formula that makes yours impossible to ignore."
      />

      {/* ── 3. STATS BAND ── */}
      <section style={{ backgroundColor: "#0D0D0D", borderTop: "1px solid rgba(255,255,255,0.06)", borderBottom: "1px solid rgba(255,255,255,0.06)", padding: "3rem 0" }}>
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <StatItem value={179} suffix="K+" label="Total Followers" />
            <StatItem value={2400} suffix="K+" label="Monthly Impressions" />
            <StatItem value={50} suffix="+" label="Brand Partnerships" />
            <StatItem value={7} suffix="M+" label="Campaign Impressions" />
          </div>
        </div>
      </section>

      {/* ── 4. BRAND LOGOS — ZoomParallax mosaic ── */}
      <BrandLogos />

      {/* ── 5. STORY TIMELINE ── */}
      <section id="story" style={{ padding: "8rem 0" }}>
        <div className="container">
          <div style={{ marginBottom: "4rem" }}>
            <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: "0.75rem" }}>
              The Story
            </span>
            <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(2.5rem, 6vw, 5rem)", color: "#fff", letterSpacing: "-0.04em", lineHeight: 0.88 }}>
              From the Big Screen<br />
              <span style={{ color: "var(--orange)" }}>to Bold Strategy.</span>
            </h2>
          </div>
          <Timeline data={TIMELINE_DATA} />
          <div style={{ display: "flex", gap: "1rem", flexWrap: "wrap", marginTop: "3rem" }}>
            <a href="https://superprofile.bio/bookings/kentcultivate?sessionId=689616ac04f931001305c667" target="_blank" rel="noopener noreferrer" className="btn-pill">
              Book 1:1 Call
              <span className="arrow-circle">→</span>
            </a>
            <a href="/agency" className="btn-pill-outline">
              Work With My Agency
            </a>
          </div>
        </div>
      </section>

      {/* ── 6. WORK — Container scroll intro + StickyTabs stacking ── */}
      <section id="work" style={{ backgroundColor: "#0D0D0D", padding: "4rem 0 0" }}>
        {/* 6a. Container scroll reveal intro */}
        <ContainerScroll
          titleComponent={
            <div style={{ textAlign: "center" }}>
              <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: "0.75rem" }}>
                02 — Results
              </span>
              <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(2.2rem, 5vw, 4rem)", color: "#fff", letterSpacing: "-0.04em", lineHeight: 0.9 }}>
                Work that speaks<br />
                <span style={{ color: "var(--orange)" }}>for itself.</span>
              </h2>
              <p style={{ fontFamily: "var(--font-body)", fontSize: "0.9rem", color: "rgba(255,255,255,0.45)", marginTop: "1rem", maxWidth: "480px", margin: "1rem auto 0" }}>
                From Fortune 500 launches to indie brand breakthroughs — the formula works.
              </p>
            </div>
          }
        >
          {/* Overview grid inside the 3D scroll frame */}
          <div style={{ height: "100%", overflowY: "auto", padding: "1.5rem" }}>
            <div className="grid grid-cols-2 gap-3" style={{ height: "100%" }}>
              {CASE_STUDIES.map((cs) => (
                <div key={cs.brand} style={{ background: "rgba(255,255,255,0.04)", border: `1px solid ${cs.color}33`, borderRadius: "10px", padding: "1.25rem", display: "flex", flexDirection: "column", gap: "0.5rem" }}>
                  <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "0.95rem", color: "#fff", letterSpacing: "-0.02em" }}>{cs.brand}</div>
                  <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.6rem", color: cs.color, letterSpacing: "-0.04em", lineHeight: 1 }}>{cs.metrics[0].val}</div>
                  <div style={{ fontFamily: "var(--font-display)", fontSize: "0.55rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "rgba(255,255,255,0.3)" }}>{cs.metrics[0].label}</div>
                </div>
              ))}
            </div>
          </div>
        </ContainerScroll>
      </section>

      {/* 6b. StickyTabs — case studies stack on scroll */}
      <StickyTabs mainNavHeight="64px">
        {CASE_STUDIES.map((cs) => (
          <StickyTabs.Item key={cs.brand} title={cs.brand} id={cs.brand}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "4rem", alignItems: "center" }}>
              {/* Left — campaign details */}
              <div>
                <span style={{ fontFamily: "var(--font-display)", fontSize: "0.6rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: cs.color, display: "block", marginBottom: "0.5rem" }}>
                  {cs.status}
                </span>
                <h3 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(1.5rem, 3vw, 2.5rem)", color: "#fff", letterSpacing: "-0.03em", lineHeight: 1.1, marginBottom: "1rem" }}>
                  {cs.campaign}
                </h3>
                <p style={{ fontFamily: "var(--font-body)", fontSize: "0.9rem", color: "rgba(255,255,255,0.5)", lineHeight: 1.8, marginBottom: "2rem" }}>
                  {cs.description}
                </p>
                <div style={{ display: "flex", gap: "2.5rem" }}>
                  {cs.metrics.map((m) => (
                    <div key={m.label}>
                      <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "2.5rem", color: cs.color, letterSpacing: "-0.04em", lineHeight: 1 }}>{m.val}</div>
                      <div style={{ fontFamily: "var(--font-display)", fontSize: "0.6rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "rgba(255,255,255,0.3)", marginTop: "0.3rem" }}>{m.label}</div>
                    </div>
                  ))}
                </div>
              </div>
              {/* Right — visual accent */}
              <div style={{ position: "relative", aspectRatio: "4/3", borderRadius: "16px", overflow: "hidden", background: `${cs.color}12`, border: `1px solid ${cs.color}22`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(4rem, 8vw, 8rem)", color: cs.color, opacity: 0.15, letterSpacing: "-0.06em", lineHeight: 1, textAlign: "center", padding: "2rem" }}>
                  {cs.metrics[0].val}
                </div>
                <div style={{ position: "absolute", bottom: "1.5rem", left: "1.5rem", right: "1.5rem" }}>
                  <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.1rem", color: "#fff", letterSpacing: "-0.02em" }}>{cs.brand}</div>
                  <div style={{ fontFamily: "var(--font-body)", fontSize: "0.75rem", color: "rgba(255,255,255,0.35)", marginTop: "0.2rem" }}>{cs.campaign}</div>
                </div>
              </div>
            </div>
          </StickyTabs.Item>
        ))}
      </StickyTabs>

      {/* ── 7. SERVICES GRID ── */}
      <section id="services" style={{ padding: "8rem 0" }}>
        <div className="container">
          <div style={{ marginBottom: "3.5rem" }}>
            <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: "0.75rem" }}>
              03 — What I Offer
            </span>
            <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(2.2rem, 5vw, 4rem)", color: "#fff", letterSpacing: "-0.04em", lineHeight: 0.9 }}>
              Let's cultivate<br />
              <span style={{ color: "var(--orange)" }}>something great.</span>
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {[
              { num: "#01", badge: "MOST POPULAR", title: "1:1 Strategy Call", sub: "Brand Clarity Session", desc: "A personalized deep dive into your content strategy, brand positioning, and audience growth. Walk away with a clear formula — not generic advice.", cta: "Book Your Call →", href: "https://superprofile.bio/bookings/kentcultivate?sessionId=689616ac04f931001305c667", external: true },
              { num: "#02", badge: "90-DAY PROGRAM", title: "Content Chemistry Cohort", sub: "Group Coaching", desc: "Your 90-day content clarity blueprint. Discover your unique story angles, get your personalized content formula, and master the psychology behind content that converts. Max 10 people.", cta: "Learn More →", href: "https://contentclinic.live", external: true },
              { num: "#03", badge: "AGENCY", title: "Element Creative Agency", sub: "End-to-End Marketing", desc: "Full-service creative production — from strategy and concept development to final execution across all platforms. We engineer campaigns that convert.", cta: "Apply to Work Together →", href: "/agency", external: false },
              { num: "#04", badge: "SPEAKING", title: "Speaking & Keynotes", sub: "Conferences, Podcasts & Events", desc: "High-energy, actionable presentations on Content Chemistry, AI-Powered Storytelling, and Scaling Brand Authority. No fluff — just frameworks that work.", cta: "Book Kent to Speak →", href: "/speaking", external: false },
            ].map((s) => (
              <div
                key={s.num}
                className="card-hover"
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "12px", padding: "2rem", display: "flex", flexDirection: "column", gap: "0.75rem" }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, color: "var(--orange)", letterSpacing: "0.05em" }}>{s.num}</span>
                  <span style={{ fontFamily: "var(--font-display)", fontSize: "0.55rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "rgba(255,255,255,0.3)", background: "rgba(255,255,255,0.06)", borderRadius: "999px", padding: "0.25rem 0.6rem" }}>{s.badge}</span>
                </div>
                <h3 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.3rem", color: "#fff", letterSpacing: "-0.02em", lineHeight: 1.1 }}>{s.title}</h3>
                <div style={{ fontFamily: "var(--font-display)", fontSize: "0.6rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "rgba(255,255,255,0.3)" }}>{s.sub}</div>
                <p style={{ fontFamily: "var(--font-body)", fontSize: "0.88rem", color: "rgba(255,255,255,0.55)", lineHeight: 1.7, flex: 1 }}>{s.desc}</p>
                <a href={s.href} target={s.external ? "_blank" : undefined} rel={s.external ? "noopener noreferrer" : undefined} style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "0.8rem", color: "var(--orange)", textDecoration: "none", letterSpacing: "0.01em", marginTop: "0.5rem" }}>
                  {s.cta}
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 8. SPEAKING TEASER ── */}
      <section style={{ position: "relative", overflow: "hidden", minHeight: "50vh", display: "flex", alignItems: "center" }}>
        <img src={SPEAKING_IMG} alt="Kent speaking" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", objectPosition: "center 30%" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to right, rgba(10,10,10,0.95) 0%, rgba(10,10,10,0.7) 60%, rgba(10,10,10,0.2) 100%)" }} />
        <div className="container" style={{ position: "relative", zIndex: 2, padding: "6rem 0" }}>
          <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: "0.75rem" }}>
            On Stage
          </span>
          <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(2.5rem, 6vw, 5rem)", color: "#fff", letterSpacing: "-0.04em", lineHeight: 0.88, marginBottom: "1.25rem" }}>
            High energy.<br />No fluff.
          </h2>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "0.95rem", color: "rgba(255,255,255,0.6)", maxWidth: "420px", lineHeight: 1.8, marginBottom: "2rem" }}>
            Kent delivers actionable strategies that audiences actually remember and use. Perfect for marketing conferences, business events, and virtual summits. 50+ speaking engagements and counting.
          </p>
          <a href="/speaking" className="btn-pill">
            Book Kent to Speak
            <span className="arrow-circle">→</span>
          </a>
        </div>
      </section>

      {/* ── 9. SOCIAL PROOF — SmoothScrollHero parallax ── */}
      <SocialProofScroll />

      {/* ── 10. TESTIMONIALS ── */}
      <section style={{ padding: "8rem 0", backgroundColor: "#0D0D0D" }}>
        <div className="container">
          <div style={{ marginBottom: "3.5rem" }}>
            <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: "0.75rem" }}>
              04 — Social Proof
            </span>
            <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(2.2rem, 5vw, 4rem)", color: "#fff", letterSpacing: "-0.04em", lineHeight: 0.9 }}>
              Results that<br />
              <span style={{ color: "var(--orange)" }}>speak for themselves.</span>
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10">
            {[
              { quote: "Kent's content strategy completely transformed my business. I went from posting randomly to having a clear, systematic approach that actually converts.", name: "Sarah M.", title: "Business Coach", result: "312% Engagement Increase" },
              { quote: "Working with Kent was a game-changer. My engagement increased by 300% and I finally built the personal brand I always wanted.", name: "Lisa T.", title: "Consultant", result: "Personal Brand Overhaul" },
              { quote: "The Content Chemistry Method gave me the exact framework I needed. No more guessing what to post — I have a proven system that works.", name: "Mike C.", title: "Course Creator", result: "Consistent Content System" },
            ].map((t) => (
              <div key={t.name} className="card-hover" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "12px", padding: "2rem", display: "flex", flexDirection: "column", gap: "1rem" }}>
                <span style={{ color: "var(--orange)", fontSize: "1.5rem", lineHeight: 1 }}>"</span>
                <p style={{ fontFamily: "var(--font-body)", fontSize: "0.9rem", color: "rgba(255,255,255,0.7)", lineHeight: 1.7, flex: 1 }}>{t.quote}</p>
                <div>
                  <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "0.9rem", color: "#fff" }}>{t.name}</div>
                  <div style={{ fontFamily: "var(--font-display)", fontSize: "0.6rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "rgba(255,255,255,0.3)", marginTop: "0.2rem" }}>{t.title}</div>
                  <div style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, color: "var(--orange)", marginTop: "0.5rem", letterSpacing: "0.02em" }}>{t.result}</div>
                </div>
              </div>
            ))}
          </div>
          {/* Client outcomes */}
          <div style={{ borderTop: "1px solid rgba(255,255,255,0.07)", paddingTop: "2.5rem" }}>
            <p style={{ fontFamily: "var(--font-display)", fontSize: "0.6rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "rgba(255,255,255,0.25)", marginBottom: "1.5rem" }}>Client Outcomes</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { result: "657% sales increase", client: "Olive Gift Co", detail: "Without raising ad budget" },
                { result: "#1 Amazon", client: "Marie Daniels", detail: "Book launch without a large following" },
                { result: "+1000% ROAS", client: "Olive Gift Co", detail: "In just 1 month — without increasing ad spend" },
              ].map((o, idx) => (
                <div key={`${o.client}-${idx}`} style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: "10px", padding: "1.25rem" }}>
                  <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.1rem", color: "var(--orange)", letterSpacing: "-0.02em" }}>{o.result}</div>
                  <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "0.85rem", color: "#fff", marginTop: "0.25rem" }}>{o.client}</div>
                  <div style={{ fontFamily: "var(--font-body)", fontSize: "0.78rem", color: "rgba(255,255,255,0.4)", marginTop: "0.25rem", lineHeight: 1.5 }}>{o.detail}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── 11. CONTACT ── */}
      <section id="contact" style={{ padding: "8rem 0" }}>
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
            <div>
              <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: "0.75rem" }}>
                05 — Get in Touch
              </span>
              <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(2.2rem, 5vw, 4rem)", color: "#fff", letterSpacing: "-0.04em", lineHeight: 0.9, marginBottom: "1.5rem" }}>
                Let's cultivate<br />
                <span style={{ color: "var(--orange)" }}>something great.</span>
              </h2>
              <p style={{ fontFamily: "var(--font-body)", fontSize: "0.9rem", color: "rgba(255,255,255,0.5)", lineHeight: 1.8, maxWidth: "360px", marginBottom: "2.5rem" }}>
                Whether you're looking for a strategic content partner, a creative director, or a keynote speaker who brings both cultural relevance and proven results — I'd love to hear about your vision.
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
                <div>
                  <div style={{ fontFamily: "var(--font-display)", fontSize: "0.6rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "rgba(255,255,255,0.25)", marginBottom: "0.25rem" }}>Email</div>
                  <a href="mailto:kent@kentcultivate.com" style={{ fontFamily: "var(--font-body)", fontSize: "0.95rem", color: "#fff", textDecoration: "none" }}>kent@kentcultivate.com</a>
                </div>
                <div>
                  <div style={{ fontFamily: "var(--font-display)", fontSize: "0.6rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "rgba(255,255,255,0.25)", marginBottom: "0.25rem" }}>Instagram</div>
                  <a href="https://instagram.com/kentcultivate" target="_blank" rel="noopener noreferrer" style={{ fontFamily: "var(--font-body)", fontSize: "0.95rem", color: "#fff", textDecoration: "none" }}>@KentCultivate</a>
                </div>
              </div>
            </div>
            <ContactForm />
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
