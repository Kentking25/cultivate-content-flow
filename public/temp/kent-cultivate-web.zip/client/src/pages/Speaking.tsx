/*
 * Speaking — Version 2 "FolioBlox Bold"
 */

import { useState } from "react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

const SPEAKING_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/93516502/NBG5nNH8rPYUKArCivqvbL/kent-speaking-LkC5VEtehNR72dDzKf3S9r.webp";

export default function Speaking() {
  const [form, setForm] = useState({ name: "", email: "", company: "", eventType: "", date: "", audience: "", topic: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const topics = [
    { num: "#01", title: "Content Chemistry", sub: "The Formula for Content That Converts", desc: "How to build a personal brand that attracts and converts without chasing trends or dancing for the algorithm." },
    { num: "#02", title: "AI-Powered Storytelling", sub: "Using Technology to Amplify Your Human Story", desc: "Practical frameworks for integrating AI into your content workflow while keeping your authentic voice front and center." },
    { num: "#03", title: "From Audience to Community", sub: "Building Loyal Tribes in the Digital Age", desc: "The psychology behind why people follow, engage, and buy — and how to engineer those outcomes intentionally." },
    { num: "#04", title: "The Creator Economy", sub: "Monetizing Your Expertise Without Selling Out", desc: "How to build multiple revenue streams from your knowledge and audience without compromising your brand integrity." },
  ];

  return (
    <div style={{ backgroundColor: "#0A0A0A", minHeight: "100vh" }}>
      <Navigation />

      {/* Hero */}
      <section style={{ position: "relative", minHeight: "60vh", display: "flex", alignItems: "flex-end", overflow: "hidden" }}>
        <img src={SPEAKING_IMG} alt="Kent speaking" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", objectPosition: "center 30%" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(10,10,10,1) 0%, rgba(10,10,10,0.7) 50%, rgba(10,10,10,0.2) 100%)" }} />
        <div className="container" style={{ position: "relative", zIndex: 2, paddingBottom: "5rem", paddingTop: "8rem" }}>
          <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: "1rem" }}>
            Speaking & Keynotes
          </span>
          <h1 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(3rem, 8vw, 6rem)", color: "#fff", letterSpacing: "-0.04em", lineHeight: 0.9, marginBottom: "1rem" }}>
            High Energy.<br /><span style={{ color: "var(--orange)" }}>No Fluff.</span>
          </h1>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "1rem", color: "rgba(255,255,255,0.6)", maxWidth: "480px", lineHeight: 1.7 }}>
            Kent delivers actionable strategies that audiences actually remember and use. 50+ speaking engagements across conferences, summits, and podcasts.
          </p>
        </div>
      </section>

      {/* Stats */}
      <section style={{ backgroundColor: "#111", borderBottom: "1px solid rgba(255,255,255,0.06)", padding: "2.5rem 0" }}>
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[{ val: "50+", label: "Speaking Engagements" }, { val: "100K+", label: "Audience Members Reached" }, { val: "4", label: "Signature Topics" }, { val: "Virtual & IRL", label: "Format Flexibility" }].map((s) => (
              <div key={s.label}>
                <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(1.5rem, 3vw, 2.5rem)", color: "#fff", letterSpacing: "-0.03em", lineHeight: 1 }}>{s.val}</div>
                <div style={{ fontFamily: "var(--font-display)", fontSize: "0.6rem", fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "rgba(255,255,255,0.35)", marginTop: "0.3rem" }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Topics */}
      <section style={{ padding: "7rem 0" }}>
        <div className="container">
          <div style={{ marginBottom: "3.5rem" }}>
            <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: "0.75rem" }}>
              Signature Topics
            </span>
            <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(2rem, 4vw, 3.5rem)", color: "#fff", letterSpacing: "-0.03em", lineHeight: 0.95 }}>
              What Kent talks about.
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {topics.map((t) => (
              <div key={t.num}
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "8px", padding: "2rem", transition: "background 0.3s ease, transform 0.3s ease" }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.05)"; (e.currentTarget as HTMLElement).style.transform = "translateY(-3px)"; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.03)"; (e.currentTarget as HTMLElement).style.transform = "translateY(0)"; }}
              >
                <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, color: "var(--orange)", letterSpacing: "0.05em" }}>{t.num}</span>
                <h3 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.3rem", color: "#fff", letterSpacing: "-0.02em", marginTop: "0.5rem", marginBottom: "0.25rem" }}>{t.title}</h3>
                <div style={{ fontFamily: "var(--font-display)", fontSize: "0.62rem", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", color: "rgba(255,255,255,0.3)", marginBottom: "0.75rem" }}>{t.sub}</div>
                <p style={{ fontFamily: "var(--font-body)", fontSize: "0.88rem", color: "rgba(255,255,255,0.55)", lineHeight: 1.7 }}>{t.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Inquiry Form */}
      <section style={{ padding: "7rem 0", backgroundColor: "#0D0D0D" }}>
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
            <div>
              <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: "0.75rem" }}>
                Book Kent
              </span>
              <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(2rem, 4vw, 3.5rem)", color: "#fff", letterSpacing: "-0.03em", lineHeight: 0.95, marginBottom: "1.5rem" }}>
                Let's make your event<br /><span style={{ color: "var(--orange)" }}>unforgettable.</span>
              </h2>
              <p style={{ fontFamily: "var(--font-body)", fontSize: "0.9rem", color: "rgba(255,255,255,0.5)", lineHeight: 1.8, maxWidth: "360px", marginBottom: "2rem" }}>
                Kent is available for keynotes, panel discussions, podcast appearances, and virtual events. Fill out the form and expect a response within 2–3 business days.
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
                {["Keynotes & Conferences", "Podcast Guest Appearances", "Panel Discussions", "Corporate Workshops", "Virtual Summits"].map((item) => (
                  <div key={item} style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
                    <span style={{ width: "6px", height: "6px", borderRadius: "50%", backgroundColor: "var(--orange)", flexShrink: 0 }} />
                    <span style={{ fontFamily: "var(--font-body)", fontSize: "0.88rem", color: "rgba(255,255,255,0.55)" }}>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              {submitted ? (
                <div style={{ padding: "3rem", border: "1px solid rgba(255,85,0,0.3)", borderRadius: "8px", textAlign: "center" }}>
                  <div style={{ color: "var(--orange)", fontSize: "2rem", marginBottom: "1rem" }}>✓</div>
                  <h3 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.25rem", color: "#fff", marginBottom: "0.5rem" }}>Inquiry Received</h3>
                  <p style={{ fontFamily: "var(--font-body)", fontSize: "0.9rem", color: "rgba(255,255,255,0.45)" }}>Kent's team will be in touch within 2–3 business days.</p>
                </div>
              ) : (
                <form onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }} className="flex flex-col gap-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="form-field"><label className="form-label">Full Name *</label><input className="form-input" type="text" placeholder="Your name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                    <div className="form-field"><label className="form-label">Email *</label><input className="form-input" type="email" placeholder="your@email.com" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
                  </div>
                  <div className="form-field"><label className="form-label">Organization *</label><input className="form-input" type="text" placeholder="Company / Event name" required value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} /></div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="form-field">
                      <label className="form-label">Event Type *</label>
                      <select className="form-input" required value={form.eventType} onChange={(e) => setForm({ ...form, eventType: e.target.value })} style={{ appearance: "none", cursor: "pointer" }}>
                        <option value="" disabled>Select type</option>
                        <option value="keynote">Keynote</option>
                        <option value="panel">Panel Discussion</option>
                        <option value="podcast">Podcast</option>
                        <option value="workshop">Workshop</option>
                        <option value="virtual">Virtual Summit</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    <div className="form-field"><label className="form-label">Event Date</label><input className="form-input" type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="form-field">
                      <label className="form-label">Audience Size</label>
                      <select className="form-input" value={form.audience} onChange={(e) => setForm({ ...form, audience: e.target.value })} style={{ appearance: "none", cursor: "pointer" }}>
                        <option value="">Select size</option>
                        <option value="under50">Under 50</option>
                        <option value="50-200">50–200</option>
                        <option value="200-500">200–500</option>
                        <option value="500-1000">500–1,000</option>
                        <option value="1000+">1,000+</option>
                      </select>
                    </div>
                    <div className="form-field">
                      <label className="form-label">Speaking Topic</label>
                      <select className="form-input" value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })} style={{ appearance: "none", cursor: "pointer" }}>
                        <option value="">Select topic</option>
                        <option value="content-chemistry">Content Chemistry</option>
                        <option value="ai-storytelling">AI-Powered Storytelling</option>
                        <option value="community">Audience to Community</option>
                        <option value="creator-economy">Creator Economy</option>
                        <option value="custom">Custom Topic</option>
                      </select>
                    </div>
                  </div>
                  <div className="form-field"><label className="form-label">Message / Additional Details</label><textarea className="form-input" placeholder="Tell me about your event, audience, and what you're hoping to achieve..." rows={4} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} style={{ resize: "vertical" }} /></div>
                  <button type="submit" className="btn-pill" style={{ alignSelf: "flex-start" }}>
                    Submit Inquiry
                    <span className="arrow-circle" style={{ background: "rgba(255,255,255,0.25)" }}>→</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
