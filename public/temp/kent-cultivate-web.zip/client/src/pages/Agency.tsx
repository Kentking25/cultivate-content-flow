/*
 * Agency — Version 2 "FolioBlox Bold"
 * Element Creative Agency application page
 */

import { useState } from "react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

const CREATIVE_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/93516502/NBG5nNH8rPYUKArCivqvbL/kent-creative-work-ThwAjQkzHLkD3wAzMXJx9Y.webp";

export default function Agency() {
  const [form, setForm] = useState({ name: "", email: "", company: "", website: "", service: "", budget: "", timeline: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const services = [
    { num: "#01", title: "Content Strategy", desc: "Comprehensive content roadmaps, audience analysis, and platform-specific strategies that drive measurable growth." },
    { num: "#02", title: "Creative Direction", desc: "End-to-end creative production — concept development, visual storytelling, and brand narrative architecture." },
    { num: "#03", title: "Brand Partnerships", desc: "Influencer strategy, creator partnerships, and campaign management that connects brands with the right audiences." },
    { num: "#04", title: "Campaign Management", desc: "Full-funnel campaign execution from ideation through launch, optimization, and reporting." },
  ];

  return (
    <div style={{ backgroundColor: "#0A0A0A", minHeight: "100vh" }}>
      <Navigation />

      {/* Hero */}
      <section style={{ position: "relative", minHeight: "60vh", display: "flex", alignItems: "flex-end", overflow: "hidden" }}>
        <img src={CREATIVE_IMG} alt="Element Creative Agency" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", objectPosition: "center" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(10,10,10,1) 0%, rgba(10,10,10,0.75) 50%, rgba(10,10,10,0.3) 100%)" }} />
        <div className="container" style={{ position: "relative", zIndex: 2, paddingBottom: "5rem", paddingTop: "8rem" }}>
          <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: "1rem" }}>
            Element Creative Agency
          </span>
          <h1 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(3rem, 8vw, 6rem)", color: "#fff", letterSpacing: "-0.04em", lineHeight: 0.9, marginBottom: "1rem" }}>
            We engineer<br /><span style={{ color: "var(--orange)" }}>experiences.</span>
          </h1>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "1rem", color: "rgba(255,255,255,0.6)", maxWidth: "480px", lineHeight: 1.7 }}>
            Full-service creative production for brands that want to convert audiences into communities and communities into customers.
          </p>
        </div>
      </section>

      {/* Services */}
      <section style={{ padding: "7rem 0" }}>
        <div className="container">
          <div style={{ marginBottom: "3.5rem" }}>
            <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: "0.75rem" }}>
              What We Do
            </span>
            <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(2rem, 4vw, 3.5rem)", color: "#fff", letterSpacing: "-0.03em", lineHeight: 0.95 }}>
              From strategy to execution.
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {services.map((s) => (
              <div key={s.num}
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "8px", padding: "2rem", transition: "background 0.3s ease, transform 0.3s ease" }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.05)"; (e.currentTarget as HTMLElement).style.transform = "translateY(-3px)"; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.03)"; (e.currentTarget as HTMLElement).style.transform = "translateY(0)"; }}
              >
                <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, color: "var(--orange)", letterSpacing: "0.05em" }}>{s.num}</span>
                <h3 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.3rem", color: "#fff", letterSpacing: "-0.02em", marginTop: "0.5rem", marginBottom: "0.75rem" }}>{s.title}</h3>
                <p style={{ fontFamily: "var(--font-body)", fontSize: "0.88rem", color: "rgba(255,255,255,0.55)", lineHeight: 1.7 }}>{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section style={{ padding: "7rem 0", backgroundColor: "#0D0D0D" }}>
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
            <div>
              <span style={{ fontFamily: "var(--font-display)", fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: "0.75rem" }}>
                Apply to Work Together
              </span>
              <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(2rem, 4vw, 3.5rem)", color: "#fff", letterSpacing: "-0.03em", lineHeight: 0.95, marginBottom: "1.5rem" }}>
                We're selective.<br /><span style={{ color: "var(--orange)" }}>Intentionally.</span>
              </h2>
              <p style={{ fontFamily: "var(--font-body)", fontSize: "0.9rem", color: "rgba(255,255,255,0.5)", lineHeight: 1.8, maxWidth: "360px", marginBottom: "2rem" }}>
                Element Creative Agency works with a limited number of clients at a time to ensure every brand gets our full attention and best work. Applications are reviewed within 5 business days.
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
                {[
                  { label: "Step 01", text: "Submit your application below" },
                  { label: "Step 02", text: "We review and reach out within 5 days" },
                  { label: "Step 03", text: "Discovery call to align on vision and scope" },
                  { label: "Step 04", text: "Custom proposal and onboarding" },
                ].map((step) => (
                  <div key={step.label} style={{ display: "flex", gap: "1rem", alignItems: "flex-start" }}>
                    <span style={{ fontFamily: "var(--font-display)", fontSize: "0.6rem", fontWeight: 700, color: "var(--orange)", letterSpacing: "0.1em", textTransform: "uppercase", marginTop: "2px", flexShrink: 0 }}>{step.label}</span>
                    <span style={{ fontFamily: "var(--font-body)", fontSize: "0.88rem", color: "rgba(255,255,255,0.5)" }}>{step.text}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              {submitted ? (
                <div style={{ padding: "3rem", border: "1px solid rgba(255,85,0,0.3)", borderRadius: "8px", textAlign: "center" }}>
                  <div style={{ color: "var(--orange)", fontSize: "2rem", marginBottom: "1rem" }}>✓</div>
                  <h3 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.25rem", color: "#fff", marginBottom: "0.5rem" }}>Application Received</h3>
                  <p style={{ fontFamily: "var(--font-body)", fontSize: "0.9rem", color: "rgba(255,255,255,0.45)" }}>The Element team will review your application and be in touch within 5 business days.</p>
                </div>
              ) : (
                <form onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }} className="flex flex-col gap-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="form-field"><label className="form-label">Full Name *</label><input className="form-input" type="text" placeholder="Your name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                    <div className="form-field"><label className="form-label">Email *</label><input className="form-input" type="email" placeholder="your@email.com" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="form-field"><label className="form-label">Brand / Company *</label><input className="form-input" type="text" placeholder="Your brand name" required value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} /></div>
                    <div className="form-field"><label className="form-label">Website</label><input className="form-input" type="url" placeholder="https://yourbrand.com" value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} /></div>
                  </div>
                  <div className="form-field">
                    <label className="form-label">Service Needed *</label>
                    <select className="form-input" required value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })} style={{ appearance: "none", cursor: "pointer" }}>
                      <option value="" disabled>Select a service</option>
                      <option value="content-strategy">Content Strategy</option>
                      <option value="creative-direction">Creative Direction</option>
                      <option value="brand-partnerships">Brand Partnerships</option>
                      <option value="campaign-management">Campaign Management</option>
                      <option value="full-service">Full-Service Partnership</option>
                    </select>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="form-field">
                      <label className="form-label">Monthly Budget</label>
                      <select className="form-input" value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} style={{ appearance: "none", cursor: "pointer" }}>
                        <option value="">Select range</option>
                        <option value="under5k">Under $5K</option>
                        <option value="5k-10k">$5K – $10K</option>
                        <option value="10k-25k">$10K – $25K</option>
                        <option value="25k-50k">$25K – $50K</option>
                        <option value="50k+">$50K+</option>
                      </select>
                    </div>
                    <div className="form-field">
                      <label className="form-label">Timeline</label>
                      <select className="form-input" value={form.timeline} onChange={(e) => setForm({ ...form, timeline: e.target.value })} style={{ appearance: "none", cursor: "pointer" }}>
                        <option value="">Select timeline</option>
                        <option value="asap">ASAP</option>
                        <option value="1month">Within 1 month</option>
                        <option value="3months">Within 3 months</option>
                        <option value="flexible">Flexible</option>
                      </select>
                    </div>
                  </div>
                  <div className="form-field"><label className="form-label">Tell Us About Your Brand & Goals *</label><textarea className="form-input" placeholder="What are you building? What results are you looking for? What's your biggest challenge right now?" required rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} style={{ resize: "vertical" }} /></div>
                  <button type="submit" className="btn-pill" style={{ alignSelf: "flex-start" }}>
                    Submit Application
                    <span className="arrow-circle" style={{ background: "rgba(255,255,255,0.25)" }}>→</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
