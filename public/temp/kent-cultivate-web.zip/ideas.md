# Kent King — Website Design Brainstorm

## Design Brief
Personal brand site for Kent King, "The Content Chemist." Mobile-first, Apple-level polish, dark editorial aesthetic, orange accent, scroll animations, hero imagery. Primary traffic from Instagram. CTAs: Book to Speak, Apply to Agency, 1:1 Consultation, Cohort Program.

---

<response>
<probability>0.07</probability>
<text>

## Idea A: "Editorial Noir"

**Design Movement:** High-fashion editorial meets Silicon Valley precision — think Dior.com crossed with Linear.app

**Core Principles:**
1. Extreme contrast — near-black backgrounds with stark white type, punctuated by a single warm amber-orange
2. Type-as-image — oversized display text that bleeds off-screen, used as structural elements not just labels
3. Cinematic pacing — sections feel like film frames; each scroll reveals a new "scene"
4. Restraint as luxury — very few elements per section, massive breathing room

**Color Philosophy:**
- Background: #0A0A0A (almost-black, not pure black — warmer)
- Foreground: #F5F0EB (warm off-white, not harsh white)
- Accent: #E8640A (Kent's orange — warm, energetic, not neon)
- Muted: #1A1A1A (card surfaces)
- Secondary text: #6B6B6B

**Layout Paradigm:**
Asymmetric full-bleed sections. Hero text anchored bottom-left (not centered). Stats float right. Images bleed off-screen edges. Navigation is minimal — just "KENT KING" wordmark left, 2-3 links right, no hamburger on desktop.

**Signature Elements:**
1. Thin horizontal rule lines (1px, 20% opacity) as section dividers — very editorial
2. Large numerals (01, 02, 03) as section markers in the background, ghosted at 5% opacity
3. Orange underline strokes on key words — not full highlights, just a 3px bottom border

**Interaction Philosophy:**
Scroll-triggered reveals. Text slides in from bottom. Images fade in with slight scale (1.05 → 1.0). Hover on CTAs: orange border traces around button perimeter. Cursor changes to crosshair on interactive elements.

**Animation:**
- Hero: Name fades in letter-by-letter (staggered), tagline slides up from below
- Stats section: Numbers count up on scroll entry
- Brand logos: Horizontal marquee ticker (infinite scroll)
- Section transitions: Clip-path wipe reveals (left to right)
- Parallax: Hero image moves at 0.5x scroll speed

**Typography System:**
- Display: "Playfair Display" — editorial serif for hero headlines and section titles
- Body/UI: "DM Sans" — clean, geometric, modern for body text and navigation
- Accent: "DM Mono" — monospace for stats, labels, small caps
- Scale: 96px hero → 48px section → 24px subhead → 16px body → 12px label

</text>
</response>

<response>
<probability>0.06</probability>
<text>

## Idea B: "Kinetic Brutalism"

**Design Movement:** New Brutalism meets luxury streetwear — think Virgil Abloh's Off-White aesthetic applied to a personal brand site

**Core Principles:**
1. Raw structure made beautiful — visible grid lines, exposed typography, intentional "unfinished" elements
2. Motion as identity — everything moves; static is boring
3. Cultural authenticity — design that feels Black creative excellence, not corporate
4. Contrast stacking — bold against subtle, fast against slow, large against small

**Color Philosophy:**
- Background: #111111 (deep charcoal)
- Primary text: #FFFFFF
- Accent: #FF6B1A (brighter orange, more electric)
- Grid/structure: rgba(255,255,255,0.08) — barely visible grid
- Highlight: #FFD700 (gold, used sparingly for "awards" type moments)

**Layout Paradigm:**
Exposed grid with visible column lines. Text breaks the grid intentionally. Rotated text labels (-90deg) on section sides. Full-viewport sections that snap on scroll. Mobile: single column, but with dramatic type scale.

**Signature Elements:**
1. Quotation marks as giant decorative elements (10vw size, orange)
2. "KENT KING" stacked vertically on left edge of hero
3. Diagonal orange slashes as decorative dividers between sections

**Interaction Philosophy:**
Magnetic buttons — cursor pulls toward CTAs. Text scramble effect on hover (letters randomize then resolve). Sections snap-scroll like Instagram stories.

**Animation:**
- Hero: Text glitches in (brief scramble → resolve)
- Scroll: Horizontal text marquee "THE CONTENT CHEMIST · CREATIVE DIRECTOR · STRATEGIST ·" 
- Brand logos: Staggered fade-in grid
- CTA buttons: Fill from left on hover

**Typography System:**
- Display: "Bebas Neue" — ultra-condensed, all-caps for maximum impact
- Body: "Space Grotesk" — geometric, technical feel
- Accent: "Courier Prime" — typewriter for quotes and labels

</text>
</response>

<response>
<probability>0.08</probability>
<text>

## Idea C: "Cinematic Presence" ← SELECTED

**Design Movement:** Apple product page meets luxury personal brand — think how Apple presents a new iPhone, but for a person

**Core Principles:**
1. The person IS the product — Kent's face, presence, and story are the hero asset
2. Scroll = reveal — each section is a chapter that unfolds as you descend
3. Precision spacing — every margin is intentional, nothing is arbitrary
4. Warmth within darkness — not cold tech dark, but rich editorial dark with organic warmth from the orange

**Color Philosophy:**
- Background: #0C0C0C (rich near-black)
- Surface: #141414 (cards, elevated sections)
- Foreground: #F2EDE8 (warm white — cream, not pure white)
- Accent: #E8640A (Kent's signature orange — warm amber-orange)
- Accent light: #FF8C3A (lighter orange for hover states)
- Muted text: #888888
- Border: rgba(255,255,255,0.08)

**Layout Paradigm:**
Full-viewport hero with Kent's image. Alternating left/right content blocks as you scroll. Stats in a horizontal band. Brand logos in a continuous marquee. Services as large tap-targets on mobile. Each section has a "breathing" quality — generous padding, nothing cramped.

**Signature Elements:**
1. Orange accent line — a thin 2px vertical line on the left of key text blocks, like a pull-quote marker
2. Oversized section numbers (01–06) in the background at 4% opacity — gives editorial depth
3. Pill-shaped tags for categories ("Creative Director", "Strategist", "Actor") in orange outline

**Interaction Philosophy:**
Smooth, purposeful. Framer Motion scroll-triggered animations. Nothing bouncy or playful — everything is deliberate and confident. Hover states are subtle: slight brightness increase, not dramatic color changes.

**Animation:**
- Hero: Fade in + slight upward drift (0.8s ease-out)
- Section headings: Slide up from 20px below, staggered per word
- Stats: Count-up animation on scroll entry
- Brand logos: Smooth infinite marquee
- Images: Subtle parallax (0.3x scroll rate)
- CTA buttons: Orange border draws around perimeter on hover (stroke animation)
- Page load: Brief flash of black, then content fades in

**Typography System:**
- Display: "Cormorant Garamond" — high-contrast serif, editorial luxury for hero and section titles
- Body/UI: "Outfit" — clean, modern geometric sans for navigation, body, and UI elements
- Mono/Labels: "JetBrains Mono" — for stats, small caps labels, technical details
- Scale: 80px hero → 52px section → 32px subhead → 18px body → 11px label (uppercase tracked)

</text>
</response>

---

## Selected Direction: **Idea C — "Cinematic Presence"**

This direction best serves Kent's brand because:
- It positions him as the product (not just a service provider)
- The Apple-level precision matches his stated reference
- Dark + orange = premium but warm, not cold corporate
- Scroll animations feel native to Instagram-trained audiences
- Cormorant Garamond + Outfit is a sophisticated pairing that reads as "creative director" not "generic marketer"
